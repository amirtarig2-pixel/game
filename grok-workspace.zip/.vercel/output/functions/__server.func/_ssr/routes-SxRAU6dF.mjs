import { i as __toESM } from "../_runtime.mjs";
import { I as require_jsx_runtime, L as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Globe, i as RotateCcw, n as Volume2, o as Crosshair, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-SxRAU6dF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FIXED_DT = 1 / 60;
var PLAYER_SPEED = 9.4;
var SPRINT_MUL = 1.22;
var ACTOR_RADIUS = .46;
var PARA_STEER = 13.5;
var WEAPONS = {
	melee: {
		id: "melee",
		name: "Blade",
		nameAr: "شفرة",
		dmg: 42,
		rpm: 110,
		mag: 0,
		reserve: 0,
		spread: 0,
		range: 2.3,
		speed: 0,
		pellets: 1,
		auto: false,
		color: 12894392
	},
	pistol: {
		id: "pistol",
		name: "Vesper",
		nameAr: "فسبر",
		dmg: 26,
		rpm: 240,
		mag: 12,
		reserve: 48,
		spread: .032,
		range: 46,
		speed: 96,
		pellets: 1,
		auto: false,
		color: 14205050
	},
	smg: {
		id: "smg",
		name: "Wasp",
		nameAr: "واسب",
		dmg: 15,
		rpm: 780,
		mag: 30,
		reserve: 90,
		spread: .068,
		range: 36,
		speed: 90,
		pellets: 1,
		auto: true,
		color: 8048840
	},
	ar: {
		id: "ar",
		name: "Ember-4",
		nameAr: "إمبر-4",
		dmg: 24,
		rpm: 580,
		mag: 30,
		reserve: 90,
		spread: .04,
		range: 64,
		speed: 118,
		pellets: 1,
		auto: true,
		color: 15228164
	},
	shotgun: {
		id: "shotgun",
		name: "Breach",
		nameAr: "بريتش",
		dmg: 13,
		rpm: 78,
		mag: 5,
		reserve: 20,
		spread: .19,
		range: 15,
		speed: 74,
		pellets: 6,
		auto: false,
		color: 12868700
	},
	sniper: {
		id: "sniper",
		name: "Longmark",
		nameAr: "لونغ مارك",
		dmg: 88,
		rpm: 46,
		mag: 5,
		reserve: 15,
		spread: .006,
		range: 130,
		speed: 170,
		pellets: 1,
		auto: false,
		color: 7252200
	}
};
var ZONE_PHASES = [
	{
		wait: 22,
		shrink: 16,
		radius: 86,
		dmg: 2
	},
	{
		wait: 16,
		shrink: 14,
		radius: 54,
		dmg: 4
	},
	{
		wait: 13,
		shrink: 12,
		radius: 30,
		dmg: 8
	},
	{
		wait: 11,
		shrink: 10,
		radius: 15,
		dmg: 14
	},
	{
		wait: 9,
		shrink: 9,
		radius: 6,
		dmg: 22
	}
];
var BOT_NAMES = [
	"KARIM",
	"NOVA",
	"RAZE",
	"MIRA",
	"FALCON",
	"ZED",
	"LAYLA",
	"GHOST",
	"OMAR",
	"NICO",
	"SABLE",
	"YARA",
	"REX",
	"DUSK",
	"KAI"
];
var BOT_COLORS = [
	3108845,
	12860271,
	3122026,
	9133311,
	14262811,
	1746849,
	13915178,
	5078174,
	12081876,
	6064698,
	13585741,
	4025804,
	10910802,
	7237240,
	14711469
];
var STATS_KEY = "blaze-drop-stats-v1";
var NAME_KEY = "blaze-drop-name";
var LANG_KEY = "blaze-drop-lang";
function VirtualStick({ onChange, onLook, look }) {
	const pid = (0, import_react.useRef)(null);
	const origin = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const last = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const end = (e) => {
		if (pid.current !== e.pointerId) return;
		pid.current = null;
		setKnob({
			x: 0,
			y: 0
		});
		onChange?.(0, 0);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative size-28 rounded-full border border-border bg-surface/55",
		onPointerDown: (e) => {
			pid.current = e.pointerId;
			e.currentTarget.setPointerCapture(e.pointerId);
			origin.current = {
				x: e.clientX,
				y: e.clientY
			};
			last.current = {
				x: e.clientX,
				y: e.clientY
			};
		},
		onPointerMove: (e) => {
			if (pid.current !== e.pointerId) return;
			if (look) {
				onLook?.(e.clientX - last.current.x, e.clientY - last.current.y);
				last.current = {
					x: e.clientX,
					y: e.clientY
				};
				const dx = e.clientX - origin.current.x;
				const dy = e.clientY - origin.current.y;
				const m = Math.min(40, Math.hypot(dx, dy));
				const a = Math.atan2(dy, dx);
				setKnob({
					x: Math.cos(a) * m,
					y: Math.sin(a) * m
				});
				return;
			}
			const dx = e.clientX - origin.current.x;
			const dy = e.clientY - origin.current.y;
			const m = Math.hypot(dx, dy);
			const r = 42;
			const k = m > r ? r / m : 1;
			const x = dx * k / r;
			const y = -dy * k / r;
			setKnob({
				x: dx * k,
				y: dy * k
			});
			onChange?.(x, y);
		},
		onPointerUp: end,
		onPointerCancel: end,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute left-1/2 top-1/2 size-11 rounded-full bg-fg/80",
			style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
		})
	});
}
var copy = {
	ar: {
		kicker: "باتل رويال",
		tag: "١٦ مقاتل · جزيرة الجمر · آخر واقف",
		start: "Start",
		startSub: "ابدأ المعركة",
		name: "الاسم",
		how: "كيف تلعب",
		hide: "إخفاء",
		howBody: [
			"الهبوط بالمظلة ثم اجمع سلاحاً ودروعاً.",
			"WASD أو العصا اليسرى للحركة. الماوس أو العصا اليمنى للنظر.",
			"اضغط للإطلاق · R لإعادة التعبئة · F للالتقاط.",
			"ابق داخل المنطقة الآمنة. الدائرة تضيق.",
			"آخر مقاتل يقف يفوز بالتاج."
		],
		matches: "مباريات",
		wins: "انتصارات",
		kills: "قتل",
		best: "أفضل مركز",
		alive: "على قيد الحياة",
		drop: "اهبط",
		outside: "خارج المنطقة",
		reload: "تعبئة",
		fire: "إطلاق",
		crowned: "التاج",
		fallen: "سقطت",
		place: "المركز",
		again: "Start",
		menu: "القائمة",
		pickup: "التقط"
	},
	en: {
		kicker: "Battle Royale",
		tag: "16 fighters · Cinder Atoll · last standing",
		start: "Start",
		startSub: "Drop into the blaze",
		name: "Callsign",
		how: "How to play",
		hide: "Hide",
		howBody: [
			"Parachute in, then loot a weapon and armor.",
			"WASD or left stick to move. Mouse or right stick to look.",
			"Click to fire · R to reload · F to pick up.",
			"Stay inside the safe zone. The ring closes.",
			"Last fighter standing takes the crown."
		],
		matches: "Matches",
		wins: "Wins",
		kills: "Kills",
		best: "Best",
		alive: "Alive",
		drop: "Steer the drop",
		outside: "Outside the zone",
		reload: "Reload",
		fire: "Fire",
		crowned: "Crowned",
		fallen: "Eliminated",
		place: "Place",
		again: "Start",
		menu: "Menu",
		pickup: "Pick up"
	}
};
function fmtTime(t) {
	const s = Math.max(0, Math.ceil(t));
	return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
}
function Minimap({ hud }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const c = ref.current;
		if (!c) return;
		const ctx = c.getContext("2d");
		if (!ctx) return;
		const w = c.width;
		const h = c.height;
		ctx.clearRect(0, 0, w, h);
		ctx.fillStyle = "rgba(20, 28, 24, 0.92)";
		ctx.fillRect(0, 0, w, h);
		const scale = w * .42 / hud.mapR;
		const cx = w / 2;
		const cy = h / 2;
		const wx = (x, z) => [cx + x * scale, cy + z * scale];
		ctx.strokeStyle = "rgba(94, 224, 192, 0.85)";
		ctx.lineWidth = 1.5;
		ctx.beginPath();
		ctx.arc(...wx(hud.zoneX, hud.zoneZ), hud.zoneR * scale, 0, Math.PI * 2);
		ctx.stroke();
		ctx.strokeStyle = "rgba(232, 93, 4, 0.35)";
		ctx.beginPath();
		ctx.arc(cx, cy, hud.mapR * scale, 0, Math.PI * 2);
		ctx.stroke();
		for (const o of hud.others) {
			const [px, pz] = wx(o.x, o.z);
			ctx.fillStyle = o.self ? "#e85d04" : "#ece8e1";
			ctx.beginPath();
			ctx.arc(px, pz, o.self ? 3.2 : 1.6, 0, Math.PI * 2);
			ctx.fill();
		}
		const self = hud.others.find((o) => o.self);
		if (self) {
			const [px, pz] = wx(self.x, self.z);
			ctx.strokeStyle = "#ece8e1";
			ctx.beginPath();
			ctx.moveTo(px, pz);
			ctx.lineTo(px - Math.sin(hud.yaw) * 8, pz - Math.cos(hud.yaw) * 8);
			ctx.stroke();
		}
	}, [hud]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		width: 148,
		height: 148,
		className: "size-[92px] rounded-md sm:size-[132px]"
	});
}
function GameOverlay({ screen, hud, stats, lang, muted, name, how, onName, onStart, onMenu, onLang, onMute, onHow, onJoy, onFire, onReload, onLook }) {
	const t = copy[lang];
	const rtl = lang === "ar";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0",
		dir: rtl ? "rtl" : "ltr",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto absolute inset-x-0 top-0 flex items-start justify-between p-3 pt-[max(0.75rem,env(safe-area-inset-top))] sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onLang,
						className: "flex size-11 items-center justify-center rounded-md border border-border bg-surface/80 text-fg",
						"aria-label": "Language",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onMute,
						className: "flex size-11 items-center justify-center rounded-md border border-border bg-surface/80 text-fg",
						"aria-label": "Mute",
						children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
					})]
				}), screen === "playing" && hud ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-border bg-surface/80 px-3 py-1.5 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-lg font-semibold tabular-nums leading-none",
							children: hud.alive
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted",
							children: t.alive
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimap, { hud })]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {})]
			}),
			screen === "playing" && hud && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute left-1/2 top-[46%] -translate-x-1/2 -translate-y-1/2 text-fg/80",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, {
						className: "size-5",
						strokeWidth: 1.75
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute left-3 top-16 flex max-w-[48%] flex-col gap-1 sm:left-5 sm:top-20",
					children: hud.feed.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "truncate rounded-sm bg-surface/70 px-2 py-1 text-xs text-fg",
						children: f.text
					}, f.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute left-1/2 top-3 w-[min(90%,20rem)] -translate-x-1/2 pt-[env(safe-area-inset-top)] text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-xs font-semibold uppercase tracking-[0.18em] text-muted",
							children: hud.shrinking ? rtl ? "الدائرة تضيق" : "Zone closing" : rtl ? "المنطقة الآمنة" : "Safe zone"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `font-display text-2xl font-semibold tabular-nums ${hud.zoneIn ? "text-fg" : "text-danger"}`,
							children: fmtTime(hud.zoneEta)
						}),
						!hud.zoneIn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-medium text-danger",
							children: t.outside
						}),
						!hud.grounded && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-fg",
							children: t.drop
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto absolute inset-x-0 bottom-0 flex flex-col gap-2 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto w-full max-w-md",
						children: [
							hud.prompt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 text-center text-sm text-fg",
								children: [
									t.pickup,
									" · ",
									hud.prompt
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex justify-between text-[11px] uppercase tracking-wider text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["HP ", Math.ceil(hud.hp)] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [hud.reloading ? t.reload : `${hud.weaponName}`, hud.magSize > 0 ? `  ${hud.mag}/${hud.reserve}` : ""] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										t.kills,
										" ",
										hud.kills
									] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 overflow-hidden rounded-full bg-elevated",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-hp",
									style: { width: `${hud.hp / hud.maxHp * 100}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 h-1.5 overflow-hidden rounded-full bg-elevated",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-armor",
									style: { width: `${hud.armor}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex gap-2",
								children: hud.slots.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `flex-1 rounded-md border px-2 py-1.5 text-center text-xs ${hud.slot === i ? "border-accent bg-elevated text-fg" : "border-border bg-surface/70 text-muted"}`,
									children: s.name
								}, i))
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between md:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VirtualStick, { onChange: onJoy }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-end gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VirtualStick, {
								look: true,
								onLook
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-end gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onPointerDown: onReload,
									className: "flex size-12 items-center justify-center rounded-full border border-border bg-surface/80",
									"aria-label": t.reload,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onPointerDown: () => onFire(true),
									onPointerUp: () => onFire(false),
									onPointerCancel: () => onFire(false),
									className: "flex size-[4.5rem] items-center justify-center rounded-full border border-accent bg-accent text-sm font-semibold text-accent-fg",
									children: t.fire
								})]
							})]
						})]
					})]
				})
			] }),
			screen === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute inset-0 flex items-end bg-gradient-to-t from-bg via-bg/55 to-transparent sm:items-center sm:justify-start",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-lg p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:p-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 font-display text-xs font-semibold uppercase tracking-[0.28em] text-accent",
							children: t.kicker
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-display text-5xl font-extrabold leading-none tracking-tight text-fg text-balance sm:text-7xl",
							children: [
								"BLAZE",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"DROP"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-sm text-pretty text-sm text-muted",
							children: t.tag
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-6 block text-xs text-muted",
							children: [t.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								onChange: (e) => onName(e.target.value.toUpperCase()),
								maxLength: 14,
								className: "mt-1 block h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm tracking-wide text-fg outline-none focus:border-accent"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onStart,
							className: "mt-4 flex h-12 w-full items-center justify-center rounded-md bg-fg text-sm font-semibold text-bg transition-transform duration-150 ease-out hover:opacity-90 active:scale-[0.98]",
							children: [
								t.start,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-2 text-subtle",
									children: "·"
								}),
								t.startSub
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onHow,
							className: "mt-2 h-11 w-full rounded-md border border-border text-sm text-muted",
							children: how ? t.hide : t.how
						}),
						how && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-1.5 text-sm text-muted",
							children: t.howBody.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 grid grid-cols-4 gap-2 border-t border-border pt-4",
							children: [
								[t.matches, stats.matches],
								[t.wins, stats.wins],
								[t.kills, stats.kills],
								[t.best, stats.best === 16 && stats.matches === 0 ? "—" : `#${stats.best}`]
							].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-lg font-semibold tabular-nums text-fg",
								children: v
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted",
								children: k
							})] }, String(k)))
						})
					]
				})
			}),
			screen === "over" && hud && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute inset-0 flex items-center justify-center bg-bg/70 p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-xl border border-border bg-surface p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xs font-semibold uppercase tracking-[0.24em] text-accent",
							children: hud.won ? t.crowned : t.fallen
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-2 font-display text-4xl font-extrabold tabular-nums",
							children: [
								t.place,
								" #",
								hud.placement
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								t.kills,
								" ",
								hud.kills
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onStart,
							className: "mt-6 flex h-12 w-full items-center justify-center rounded-md bg-fg text-sm font-semibold text-bg",
							children: t.again
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onMenu,
							className: "mt-2 h-11 w-full rounded-md border border-border text-sm text-muted",
							children: t.menu
						})
					]
				})
			})
		]
	});
}
function loadStats() {
	try {
		const raw = localStorage.getItem(STATS_KEY);
		if (raw) return JSON.parse(raw);
	} catch {}
	return {
		name: "RANGER",
		matches: 0,
		wins: 0,
		kills: 0,
		best: 16
	};
}
function saveStats(s) {
	localStorage.setItem(STATS_KEY, JSON.stringify(s));
}
var enginePromise = typeof window === "undefined" ? null : import("./engine-Do2n0c4g.mjs");
function GameView() {
	const canvasRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const pendingStart = (0, import_react.useRef)(null);
	const [hud, setHud] = (0, import_react.useState)(null);
	const [screen, setScreen] = (0, import_react.useState)("menu");
	const [stats, setStats] = (0, import_react.useState)({
		name: "RANGER",
		matches: 0,
		wins: 0,
		kills: 0,
		best: 16
	});
	const [lang, setLang] = (0, import_react.useState)("ar");
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("RANGER");
	const [how, setHow] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const n = localStorage.getItem(NAME_KEY);
			if (n) setName(n);
			const l = localStorage.getItem(LANG_KEY);
			if (l === "en" || l === "ar") setLang(l);
			setStats(loadStats());
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang === "ar" ? "ar" : "en";
		document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
	}, [lang]);
	(0, import_react.useEffect)(() => {
		if (!canvasRef.current) return;
		let cancelled = false;
		let game = null;
		(enginePromise ?? import("./engine-Do2n0c4g.mjs")).then(({ BlazeGame }) => {
			if (cancelled || !canvasRef.current) return;
			const inst = new BlazeGame(canvasRef.current, {
				onHud: (h) => setHud(h),
				onOver: (won, place, kills) => {
					setScreen("over");
					setStats((prev) => {
						const next = {
							...prev,
							matches: prev.matches + 1,
							wins: prev.wins + (won ? 1 : 0),
							kills: prev.kills + kills,
							best: Math.min(prev.best || 16, place),
							name: prev.name
						};
						saveStats(next);
						return next;
					});
				}
			});
			if (cancelled) {
				inst.destroy();
				return;
			}
			game = inst;
			gameRef.current = inst;
			const queued = pendingStart.current;
			if (queued) {
				pendingStart.current = null;
				inst.audio.unlock();
				inst.setName(queued);
				inst.startMatch(queued);
				setScreen("playing");
			}
		});
		const onVis = () => {
			if (!document.hidden) gameRef.current?.audio.unlock();
		};
		document.addEventListener("visibilitychange", onVis);
		return () => {
			cancelled = true;
			document.removeEventListener("visibilitychange", onVis);
			game?.destroy();
			gameRef.current = null;
		};
	}, []);
	const start = (0, import_react.useCallback)(() => {
		const g = gameRef.current;
		const trimmed = name.trim().slice(0, 14) || "RANGER";
		setName(trimmed);
		try {
			localStorage.setItem(NAME_KEY, trimmed);
		} catch {}
		if (!g) {
			pendingStart.current = trimmed;
			return;
		}
		g.audio.unlock();
		g.setName(trimmed);
		g.startMatch(trimmed);
		setScreen("playing");
		setStats((s) => ({
			...s,
			name: trimmed
		}));
	}, [name]);
	const backToMenu = (0, import_react.useCallback)(() => {
		setScreen("menu");
	}, []);
	const toggleLang = (0, import_react.useCallback)(() => {
		setLang((l) => {
			const n = l === "ar" ? "en" : "ar";
			try {
				localStorage.setItem(LANG_KEY, n);
			} catch {}
			return n;
		});
	}, []);
	const toggleMute = (0, import_react.useCallback)(() => {
		setMuted((m) => {
			const next = !m;
			gameRef.current?.audio.setMuted(next);
			return next;
		});
	}, []);
	const onJoy = (0, import_react.useCallback)((x, y) => {
		const g = gameRef.current;
		if (!g) return;
		g.input.joyX = x;
		g.input.joyY = y;
	}, []);
	const onFire = (0, import_react.useCallback)((down) => {
		const g = gameRef.current;
		if (!g) return;
		g.input.fireHeld = down;
		if (down) g.input.fireQueued = true;
	}, []);
	const onReload = (0, import_react.useCallback)(() => {
		const g = gameRef.current;
		if (g) g.input.reloadQueued = true;
	}, []);
	const onLook = (0, import_react.useCallback)((dx, dy) => {
		const g = gameRef.current;
		if (!g) return;
		g.input.lookDx += dx;
		g.input.lookDy += dy;
		g.input.mouseLooking = .5;
	}, []);
	const requestLock = (0, import_react.useCallback)(() => {
		if (screen !== "playing") return;
		const canvas = canvasRef.current;
		if (!canvas) return;
		gameRef.current?.audio.unlock();
		const req = canvas.requestPointerLock;
		try {
			const p = req.call(canvas, { unadjustedMovement: true });
			if (p && typeof p.catch === "function") p.catch(() => {
				canvas.requestPointerLock();
			});
		} catch {
			try {
				canvas.requestPointerLock();
			} catch {}
		}
	}, [screen]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		style: { touchAction: "none" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "absolute inset-0 h-full w-full",
			onClick: requestLock,
			onContextMenu: (e) => e.preventDefault()
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameOverlay, {
			screen,
			hud,
			stats,
			lang,
			muted,
			name,
			how,
			onName: setName,
			onStart: start,
			onMenu: backToMenu,
			onLang: toggleLang,
			onMute: toggleMute,
			onHow: () => setHow((v) => !v),
			onJoy,
			onFire,
			onReload,
			onLook
		})]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameView, {});
}
//#endregion
export { FIXED_DT as a, SPRINT_MUL as c, BOT_NAMES as i, WEAPONS as l, ACTOR_RADIUS as n, PARA_STEER as o, BOT_COLORS as r, PLAYER_SPEED as s, routes_exports as t, ZONE_PHASES as u };
