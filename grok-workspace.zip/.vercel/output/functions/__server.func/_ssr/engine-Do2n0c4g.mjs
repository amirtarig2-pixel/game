import { a as FIXED_DT, c as SPRINT_MUL, i as BOT_NAMES, l as WEAPONS, n as ACTOR_RADIUS, o as PARA_STEER, r as BOT_COLORS, s as PLAYER_SPEED, u as ZONE_PHASES } from "./routes-SxRAU6dF.mjs";
import { C as SphereGeometry, S as Scene, _ as MeshLambertMaterial, a as CircleGeometry, b as RingGeometry, c as CylinderGeometry, d as Fog, f as Group, g as MeshBasicMaterial, h as Mesh, i as CapsuleGeometry, l as DirectionalLight, m as InstancedMesh, n as BoxGeometry, o as Color, p as HemisphereLight, r as BufferAttribute, s as ConeGeometry, t as WebGLRenderer, u as DodecahedronGeometry, v as Object3D, w as Vector3, x as SRGBColorSpace, y as PerspectiveCamera } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-Do2n0c4g.js
var GameAudio = class {
	ctx = null;
	master = null;
	sfx = null;
	muted = false;
	unlock() {
		if (!this.ctx) {
			const Ctx = window.AudioContext || window.webkitAudioContext;
			this.ctx = new Ctx({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.sfx = this.ctx.createGain();
			this.sfx.gain.value = .7;
			this.sfx.connect(this.master);
			this.master.connect(this.ctx.destination);
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	setMuted(v) {
		this.muted = v;
		if (this.master && this.ctx) this.master.gain.setTargetAtTime(v ? 0 : 1, this.ctx.currentTime, .03);
	}
	beep(freq, dur, type, gain, slide = 0) {
		if (!this.ctx || !this.sfx || this.muted) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq, t);
		if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
		g.gain.setValueAtTime(gain, t);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		osc.connect(g);
		g.connect(this.sfx);
		osc.start(t);
		osc.stop(t + dur + .02);
		osc.onended = () => {
			osc.disconnect();
			g.disconnect();
		};
	}
	noise(dur, gain, hp = 800) {
		if (!this.ctx || !this.sfx || this.muted) return;
		const n = this.ctx.sampleRate * dur;
		const buf = this.ctx.createBuffer(1, n, this.ctx.sampleRate);
		const data = buf.getChannelData(0);
		for (let i = 0; i < n; i++) data[i] = Math.random() * 2 - 1;
		const src = this.ctx.createBufferSource();
		src.buffer = buf;
		const filter = this.ctx.createBiquadFilter();
		filter.type = "highpass";
		filter.frequency.value = hp;
		const g = this.ctx.createGain();
		const t = this.ctx.currentTime;
		g.gain.setValueAtTime(gain, t);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		src.connect(filter);
		filter.connect(g);
		g.connect(this.sfx);
		src.start(t);
		src.stop(t + dur);
		src.onended = () => {
			src.disconnect();
			filter.disconnect();
			g.disconnect();
		};
	}
	shoot(heavy = false) {
		this.noise(heavy ? .09 : .05, heavy ? .22 : .12, heavy ? 400 : 1200);
		this.beep(heavy ? 140 : 280, .07, "square", .05, -80);
	}
	hit() {
		this.beep(180, .08, "sawtooth", .08, -60);
	}
	pickup() {
		this.beep(520, .08, "sine", .07, 180);
		this.beep(780, .1, "sine", .05, 40);
	}
	hurt() {
		this.noise(.12, .16, 200);
		this.beep(90, .14, "triangle", .1, -40);
	}
	win() {
		this.beep(392, .18, "square", .08);
		this.beep(494, .18, "square", .08);
		this.beep(587, .28, "square", .09);
	}
	lose() {
		this.beep(220, .3, "sawtooth", .08, -120);
	}
	zone() {
		this.beep(70, .25, "sine", .06);
	}
};
var GAME_CODES = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight",
	"Space",
	"KeyR",
	"KeyF",
	"KeyE",
	"ShiftLeft",
	"ShiftRight",
	"Digit1",
	"Digit2",
	"Digit3",
	"KeyQ"
]);
var GameInput = class {
	keys = /* @__PURE__ */ new Set();
	injected = null;
	lookDx = 0;
	lookDy = 0;
	fireHeld = false;
	fireQueued = false;
	reloadQueued = false;
	interactQueued = false;
	joyX = 0;
	joyY = 0;
	lookStickX = 0;
	lookStickY = 0;
	slotQueued = null;
	mouseLooking = 0;
	pointerLocked = false;
	attach() {
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.clear);
		document.addEventListener("visibilitychange", this.onVis);
		window.addEventListener("mousemove", this.onMouse, true);
		window.addEventListener("mousedown", this.onMouseDown, true);
		window.addEventListener("mouseup", this.onMouseUp, true);
		document.addEventListener("pointerlockchange", this.onLock);
	}
	detach() {
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.clear);
		document.removeEventListener("visibilitychange", this.onVis);
		window.removeEventListener("mousemove", this.onMouse, true);
		window.removeEventListener("mousedown", this.onMouseDown, true);
		window.removeEventListener("mouseup", this.onMouseUp, true);
		document.removeEventListener("pointerlockchange", this.onLock);
	}
	onLock = () => {
		this.pointerLocked = document.pointerLockElement != null;
	};
	onKeyDown = (e) => {
		if (GAME_CODES.has(e.code)) e.preventDefault();
		this.keys.add(e.code);
		if (e.code === "KeyR") this.reloadQueued = true;
		if (e.code === "KeyF" || e.code === "KeyE") this.interactQueued = true;
		if (e.code === "Digit1") this.slotQueued = 0;
		if (e.code === "Digit2") this.slotQueued = 1;
		if (e.code === "Digit3") this.slotQueued = 2;
		if (e.code === "KeyQ") this.slotQueued = -1;
	};
	onKeyUp = (e) => {
		this.keys.delete(e.code);
	};
	onVis = () => {
		if (document.hidden) this.clear();
	};
	onMouse = (e) => {
		if (!this.pointerLocked && e.buttons === 0) return;
		this.lookDx += e.movementX;
		this.lookDy += e.movementY;
		this.mouseLooking = .45;
	};
	onMouseDown = (e) => {
		if (e.button === 0) {
			this.fireHeld = true;
			this.fireQueued = true;
		}
	};
	onMouseUp = (e) => {
		if (e.button === 0) this.fireHeld = false;
	};
	clear = () => {
		this.keys.clear();
		this.fireHeld = false;
		this.joyX = 0;
		this.joyY = 0;
	};
	setKeys(codes) {
		this.injected = codes.length ? [...codes] : null;
	}
	down(code) {
		if (this.injected) return this.injected.includes(code);
		return this.keys.has(code);
	}
	sampleMove() {
		let x = this.joyX;
		let y = this.joyY;
		if (this.down("KeyA") || this.down("ArrowLeft")) x -= 1;
		if (this.down("KeyD") || this.down("ArrowRight")) x += 1;
		if (this.down("KeyW") || this.down("ArrowUp")) y += 1;
		if (this.down("KeyS") || this.down("ArrowDown")) y -= 1;
		this.pollGamepad();
		let padFire = false;
		const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : [];
		if (pads) for (const p of pads) {
			if (!p || p.mapping !== "standard") continue;
			x += this.dead(p.axes[0] ?? 0, p.axes[1] ?? 0).x;
			y -= this.dead(p.axes[0] ?? 0, p.axes[1] ?? 0).y;
			const look = this.dead(p.axes[2] ?? 0, p.axes[3] ?? 0, .18);
			this.lookDx += look.x * 14;
			this.lookDy += look.y * 10;
			if (p.buttons[7]?.value && p.buttons[7].value > .4) padFire = true;
		}
		if (padFire) {
			this.fireHeld = true;
			this.fireQueued = true;
		}
		const len = Math.hypot(x, y);
		if (len > 1) {
			x /= len;
			y /= len;
		}
		const sprint = this.down("ShiftLeft") || this.down("ShiftRight");
		return {
			x,
			y,
			sprint
		};
	}
	consumeLook() {
		const dx = this.lookDx + this.lookStickX * 10;
		const dy = this.lookDy + this.lookStickY * 8;
		this.lookDx = 0;
		this.lookDy = 0;
		return {
			dx,
			dy
		};
	}
	dead(x, y, dz = .16) {
		const m = Math.hypot(x, y);
		if (m < dz) return {
			x: 0,
			y: 0
		};
		const scale = (m - dz) / (1 - dz) / m;
		return {
			x: x * scale,
			y: y * scale
		};
	}
	pollGamepad() {}
};
function mulberry(seed) {
	let a = seed >>> 0;
	return () => {
		a += 1831565813;
		let t = a;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function angLerp(a, b, t) {
	let d = b - a;
	while (d > Math.PI) d -= Math.PI * 2;
	while (d < -Math.PI) d += Math.PI * 2;
	return a + d * t;
}
function clamp(v, lo, hi) {
	return Math.max(lo, Math.min(hi, v));
}
var BlazeGame = class {
	renderer;
	scene = new Scene();
	camera = new PerspectiveCamera(62, 1, .12, 420);
	input = new GameInput();
	audio = new GameAudio();
	mode = "menu";
	playerName = "YOU";
	lang = "ar";
	actors = [];
	loot = [];
	bullets = [];
	buildings = [];
	zone = {
		x: 0,
		z: 0,
		r: 86,
		tx: 0,
		tz: 0,
		tr: 86,
		phase: 0,
		t: 0,
		shrinking: false,
		dmg: 0
	};
	feed = [];
	feedId = 0;
	kills = 0;
	matchTime = 0;
	overT = 0;
	won = false;
	placement = 16;
	camYaw = 0;
	camPitch = -.28;
	trauma = 0;
	hitstop = 0;
	clock = 0;
	acc = 0;
	hudAcc = 0;
	last = 0;
	raf = 0;
	alive = true;
	onHud;
	onOver;
	shared;
	mats;
	zoneRing;
	zoneWall;
	planeMesh;
	particles = [];
	spawnPlane = {
		x: -90,
		z: 0,
		a: 0
	};
	tmp = new Vector3();
	tmp2 = new Vector3();
	injectedSteer = null;
	prompt = null;
	constructor(canvas, hooks) {
		this.onHud = hooks.onHud;
		this.onOver = hooks.onOver;
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: true,
			alpha: false,
			powerPreference: "high-performance"
		});
		this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
		this.renderer.setClearColor(7252168, 1);
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.renderer.shadowMap.enabled = false;
		this.scene.fog = new Fog(8302532, 48, 210);
		this.shared = {
			body: new CapsuleGeometry(.32, .64, 3, 8),
			head: new SphereGeometry(.26, 8, 6),
			pack: new BoxGeometry(.32, .38, .16),
			visor: new BoxGeometry(.28, .1, .08),
			gun: new BoxGeometry(.08, .1, .7),
			barrel: new BoxGeometry(.05, .05, .28),
			mag: new BoxGeometry(.07, .16, .12),
			crate: new BoxGeometry(.7, .55, .7),
			bullet: new SphereGeometry(.08, 6, 4),
			particle: new SphereGeometry(.07, 5, 4),
			blob: new CircleGeometry(.55, 10),
			canopy: new ConeGeometry(1.35, 2.6, 7),
			trunk: new CylinderGeometry(.16, .22, 1.4, 5),
			rock: new DodecahedronGeometry(.9, 0)
		};
		this.mats = {
			grass: new MeshLambertMaterial({ vertexColors: true }),
			sand: new MeshLambertMaterial({ color: 13217914 }),
			water: new MeshLambertMaterial({
				color: 2784936,
				transparent: true,
				opacity: .92
			}),
			roof: new MeshLambertMaterial({ color: 6963248 }),
			wall: new MeshLambertMaterial({ color: 13155496 }),
			wall2: new MeshLambertMaterial({ color: 9411235 }),
			crate: new MeshLambertMaterial({ color: 12868118 }),
			trunk: new MeshLambertMaterial({ color: 5913122 }),
			canopy: new MeshLambertMaterial({ color: 2059066 }),
			canopy2: new MeshLambertMaterial({ color: 2984522 }),
			rock: new MeshLambertMaterial({ color: 8025452 }),
			zone: new MeshBasicMaterial({
				color: 6217920,
				transparent: true,
				opacity: .22,
				side: 2
			}),
			wallZone: new MeshBasicMaterial({
				color: 6217920,
				transparent: true,
				opacity: .07,
				side: 2
			}),
			bullet: new MeshBasicMaterial({ color: 16769162 }),
			ebullet: new MeshBasicMaterial({ color: 16738906 }),
			blob: new MeshBasicMaterial({
				color: 0,
				transparent: true,
				opacity: .28,
				depthWrite: false
			}),
			particle: new MeshBasicMaterial({ color: 16756848 })
		};
		this.buildWorld();
		this.zoneRing = new Mesh(new RingGeometry(85.2, 86.4, 64), this.mats.zone);
		this.zoneRing.rotation.x = -Math.PI / 2;
		this.zoneRing.position.y = .08;
		this.scene.add(this.zoneRing);
		this.zoneWall = new Mesh(new CylinderGeometry(86, 86, 18, 64, 1, true), this.mats.wallZone);
		this.zoneWall.position.y = 9;
		this.scene.add(this.zoneWall);
		this.planeMesh = new Group();
		const fus = new Mesh(new BoxGeometry(2.2, .7, 8.5), new MeshLambertMaterial({ color: 14209734 }));
		const wing = new Mesh(new BoxGeometry(11, .12, 2.2), new MeshLambertMaterial({ color: 15228164 }));
		wing.position.y = .1;
		this.planeMesh.add(fus, wing);
		this.planeMesh.position.set(-120, 36, 0);
		this.scene.add(this.planeMesh);
		this.makeBulletPool();
		this.makeParticlePool();
		this.resize();
		this.input.attach();
		this.last = performance.now();
		this.loop = this.loop.bind(this);
		this.raf = requestAnimationFrame(this.loop);
		window.addEventListener("resize", this.resize);
		this.wireProbe();
		this.orbitMenu(0);
		this.pushHud(true);
	}
	destroy() {
		this.alive = false;
		cancelAnimationFrame(this.raf);
		window.removeEventListener("resize", this.resize);
		this.input.detach();
		if (window.__controlsTest) delete window.__controlsTest;
		this.renderer.dispose();
		for (const g of Object.values(this.shared)) g.dispose();
		for (const m of Object.values(this.mats)) m.dispose();
	}
	setName(n) {
		this.playerName = n.slice(0, 14) || "YOU";
		const p = this.actors.find((a) => a.player);
		if (p) p.name = this.playerName;
	}
	resize = () => {
		const c = this.renderer.domElement;
		const w = c.clientWidth || window.innerWidth;
		const h = c.clientHeight || window.innerHeight;
		this.renderer.setSize(w, h, false);
		this.camera.aspect = w / Math.max(1, h);
		this.camera.updateProjectionMatrix();
	};
	startMatch(name) {
		this.playerName = name.slice(0, 14) || "YOU";
		this.audio.unlock();
		this.mode = "playing";
		this.kills = 0;
		this.matchTime = 0;
		this.won = false;
		this.overT = 0;
		this.feed = [];
		this.camYaw = 0;
		this.camPitch = -.32;
		this.trauma = 0;
		this.zone = {
			x: 0,
			z: 0,
			r: 86,
			tx: 0,
			tz: 0,
			tr: 86,
			phase: 0,
			t: ZONE_PHASES[0].wait,
			shrinking: false,
			dmg: 0
		};
		this.resetActors();
		this.respawnLoot();
		for (const b of this.bullets) b.live = false;
		this.spawnPlane = {
			x: -92,
			z: (this.rng() - .5) * 20,
			a: 0
		};
		this.planeMesh.position.set(this.spawnPlane.x, 34, this.spawnPlane.z);
		this.planeMesh.rotation.y = Math.PI / 2;
		this.wireProbe();
		this.pushHud(true);
	}
	rng = mulberry(12703717);
	buildWorld() {
		const hemi = new HemisphereLight(13625599, 4020786, 1.05);
		const sun = new DirectionalLight(16773590, 1.15);
		sun.position.set(-40, 70, 22);
		this.scene.add(hemi, sun);
		const water = new Mesh(new CircleGeometry(134, 48), this.mats.water);
		water.rotation.x = -Math.PI / 2;
		water.position.y = -.25;
		this.scene.add(water);
		const groundGeo = new CircleGeometry(88, 96);
		const pos = groundGeo.attributes.position;
		const colors = new Float32Array(pos.count * 3);
		const c = new Color();
		for (let i = 0; i < pos.count; i++) {
			const x = pos.getX(i);
			const z = pos.getY(i);
			const r = Math.hypot(x, z);
			const n = Math.sin(x * .12) * Math.cos(z * .11) + Math.sin(x * .41 + z * .2) * .35;
			if (r > 79) c.set(13809018);
			else if (n > .55) c.set(4880946);
			else if (n < -.45) c.set(7035448);
			else c.set(4160058);
			colors[i * 3] = c.r;
			colors[i * 3 + 1] = c.g;
			colors[i * 3 + 2] = c.b;
		}
		groundGeo.setAttribute("color", new BufferAttribute(colors, 3));
		groundGeo.rotateX(-Math.PI / 2);
		const ground = new Mesh(groundGeo, this.mats.grass);
		this.scene.add(ground);
		this.placeTown(-28, -8, "Port");
		this.placeTown(32, 18, "Ruins");
		this.placeTown(6, -36, "Camp");
		this.placeTown(-12, 38, "Ridge");
		this.scatterNature();
	}
	placeTown(cx, cz, _name) {
		const n = 5 + Math.floor(this.rng() * 3);
		for (let i = 0; i < n; i++) {
			const w = 4.2 + this.rng() * 5.5;
			const d = 3.6 + this.rng() * 5;
			const h = 3.2 + this.rng() * 4.4;
			const x = cx + (this.rng() - .5) * 22;
			const z = cz + (this.rng() - .5) * 22;
			if (Math.hypot(x, z) > 76) continue;
			const wallMat = this.rng() > .5 ? this.mats.wall : this.mats.wall2;
			const box = new Mesh(new BoxGeometry(w, h, d), wallMat);
			box.position.set(x, h / 2, z);
			const roof = new Mesh(new BoxGeometry(w + .4, .28, d + .4), this.mats.roof);
			roof.position.set(x, h + .12, z);
			this.scene.add(box, roof);
			this.buildings.push({
				minX: x - w / 2,
				maxX: x + w / 2,
				minZ: z - d / 2,
				maxZ: z + d / 2,
				h
			});
		}
	}
	scatterNature() {
		const canopy = new InstancedMesh(this.shared.canopy, this.mats.canopy, 70);
		const trunk = new InstancedMesh(this.shared.trunk, this.mats.trunk, 70);
		const dummy = new Object3D();
		let placed = 0;
		let guard = 0;
		while (placed < 70 && guard < 400) {
			guard++;
			const a = this.rng() * Math.PI * 2;
			const r = 8 + this.rng() * 72;
			const x = Math.cos(a) * r;
			const z = Math.sin(a) * r;
			if (this.hitBuild(x, z, 1.6)) continue;
			dummy.position.set(x, 2.3, z);
			dummy.rotation.y = this.rng() * 6;
			dummy.scale.setScalar(.75 + this.rng() * .6);
			dummy.updateMatrix();
			canopy.setMatrixAt(placed, dummy.matrix);
			dummy.position.set(x, .7, z);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			trunk.setMatrixAt(placed, dummy.matrix);
			placed++;
		}
		this.scene.add(canopy, trunk);
		const rocks = new InstancedMesh(this.shared.rock, this.mats.rock, 28);
		for (let i = 0; i < 28; i++) {
			const a = this.rng() * Math.PI * 2;
			const r = 10 + this.rng() * 78;
			dummy.position.set(Math.cos(a) * r, .2, Math.sin(a) * r);
			dummy.rotation.set(this.rng(), this.rng(), this.rng());
			dummy.scale.setScalar(.5 + this.rng() * 1.1);
			dummy.updateMatrix();
			rocks.setMatrixAt(i, dummy.matrix);
		}
		this.scene.add(rocks);
	}
	makeActor(id, name, color, player) {
		const g = new Group();
		const bodyMat = new MeshLambertMaterial({ color });
		const dark = new MeshLambertMaterial({ color: 1711136 });
		const skin = new MeshLambertMaterial({ color: 14725257 });
		const body = new Mesh(this.shared.body, bodyMat);
		body.position.y = .9;
		const head = new Mesh(this.shared.head, skin);
		head.position.y = 1.54;
		const visor = new Mesh(this.shared.visor, dark);
		visor.position.set(0, 1.56, -.18);
		const pack = new Mesh(this.shared.pack, dark);
		pack.position.set(0, 1.05, .28);
		const gun = new Group();
		const gb = new Mesh(this.shared.gun, dark);
		const barrel = new Mesh(this.shared.barrel, dark);
		barrel.position.z = -.46;
		const mag = new Mesh(this.shared.mag, dark);
		mag.position.set(0, -.12, .05);
		gun.add(gb, barrel, mag);
		gun.position.set(.28, 1.05, -.35);
		const blob = new Mesh(this.shared.blob, this.mats.blob);
		blob.rotation.x = -Math.PI / 2;
		blob.position.y = .03;
		g.add(body, head, visor, pack, gun, blob);
		this.scene.add(g);
		return {
			id,
			name,
			player,
			x: 0,
			y: 28,
			z: 0,
			yaw: 0,
			vx: 0,
			vz: 0,
			hp: 200,
			armor: 0,
			alive: true,
			grounded: false,
			slots: [null, null],
			slot: 0,
			mag: 0,
			reserve: 0,
			lastShot: 0,
			reload: 0,
			color,
			mesh: g,
			bodyMat,
			gunMesh: gun,
			ai: 0,
			aiT: 0,
			aimX: 0,
			aimZ: -1,
			flash: 0,
			kills: 0
		};
	}
	resetActors() {
		for (const a of this.actors) this.scene.remove(a.mesh);
		this.actors = [];
		const p = this.makeActor(0, this.playerName, 15228164, true);
		this.actors.push(p);
		for (let i = 1; i < 16; i++) this.actors.push(this.makeActor(i, BOT_NAMES[i - 1] ?? `P${i}`, BOT_COLORS[(i - 1) % BOT_COLORS.length], false));
		const dropZ = (this.rng() - .5) * 18;
		for (let i = 0; i < this.actors.length; i++) {
			const a = this.actors[i];
			a.x = -40 - this.rng() * 30 + (this.rng() - .5) * 8;
			a.z = dropZ + (i - 8) * 2.4 + (this.rng() - .5) * 6;
			a.y = 26 + this.rng() * 6;
			a.yaw = Math.PI / 2;
			a.grounded = false;
			a.alive = true;
			a.hp = 200;
			a.armor = 0;
			a.slots = [null, null];
			a.slot = 0;
			a.mag = 0;
			a.reserve = 0;
			a.mesh.visible = true;
		}
	}
	respawnLoot() {
		for (const l of this.loot) this.scene.remove(l.mesh);
		this.loot = [];
		const dummyKinds = [...[
			"pistol",
			"pistol",
			"smg",
			"smg",
			"smg",
			"ar",
			"ar",
			"ar",
			"ar",
			"shotgun",
			"shotgun",
			"sniper",
			"sniper",
			"ammo",
			"ammo",
			"ammo",
			"ammo",
			"ammo",
			"med",
			"med",
			"med",
			"med",
			"armor",
			"armor",
			"armor",
			"pistol",
			"ar",
			"smg",
			"ammo",
			"med"
		]];
		while (dummyKinds.length < 56) dummyKinds.push(this.rng() > .5 ? "ammo" : "med");
		for (const kind of dummyKinds) {
			let x = 0, z = 0, ok = false;
			for (let t = 0; t < 12; t++) {
				const a = this.rng() * Math.PI * 2;
				const r = 6 + this.rng() * 74;
				x = Math.cos(a) * r;
				z = Math.sin(a) * r;
				if (!this.hitBuild(x, z, 1.2)) {
					ok = true;
					break;
				}
			}
			if (!ok) continue;
			const isGun = kind in WEAPONS && kind !== "melee";
			const mesh = new Mesh(this.shared.crate, new MeshLambertMaterial({ color: isGun ? WEAPONS[kind].color : kind === "med" ? 4116334 : kind === "armor" ? 4891624 : 14205050 }));
			mesh.position.set(x, .32, z);
			this.scene.add(mesh);
			this.loot.push({
				kind,
				x,
				z,
				mesh,
				live: true
			});
		}
	}
	makeBulletPool() {
		for (let i = 0; i < 80; i++) {
			const mesh = new Mesh(this.shared.bullet, this.mats.bullet);
			mesh.visible = false;
			this.scene.add(mesh);
			this.bullets.push({
				live: false,
				x: 0,
				y: 0,
				z: 0,
				vx: 0,
				vy: 0,
				vz: 0,
				ttl: 0,
				dmg: 0,
				owner: 0,
				mesh
			});
		}
	}
	makeParticlePool() {
		for (let i = 0; i < 64; i++) {
			const m = new Mesh(this.shared.particle, this.mats.particle);
			m.visible = false;
			this.scene.add(m);
			this.particles.push({
				m,
				vx: 0,
				vy: 0,
				vz: 0,
				t: 0
			});
		}
	}
	hitBuild(x, z, r) {
		for (const b of this.buildings) if (x + r > b.minX && x - r < b.maxX && z + r > b.minZ && z - r < b.maxZ) return b;
		return null;
	}
	resolve(a, r = ACTOR_RADIUS) {
		for (const b of this.buildings) {
			if (a.y > b.h + .4) continue;
			const cx = clamp(a.x, b.minX, b.maxX);
			const cz = clamp(a.z, b.minZ, b.maxZ);
			const dx = a.x - cx;
			const dz = a.z - cz;
			const d = Math.hypot(dx, dz);
			if (d < r && d > 1e-4) {
				const p = (r - d) / d;
				a.x += dx * p;
				a.z += dz * p;
			} else if (d < 1e-4) a.x += r;
		}
		const md = Math.hypot(a.x, a.z);
		if (md > 84.8) {
			const s = 84.8 / md;
			a.x *= s;
			a.z *= s;
		}
	}
	weaponOf(a) {
		return a.slots[a.slot] ?? "melee";
	}
	loop(now) {
		if (!this.alive) return;
		const raw = Math.min(.1, (now - this.last) / 1e3);
		this.last = now;
		this.acc += raw;
		while (this.acc >= FIXED_DT) {
			if (this.hitstop > 0) this.hitstop -= FIXED_DT;
			else this.sim(FIXED_DT);
			this.acc -= FIXED_DT;
		}
		this.draw(raw);
		this.hudAcc += raw;
		if (this.hudAcc > .09) {
			this.hudAcc = 0;
			this.pushHud(false);
		}
		this.raf = requestAnimationFrame(this.loop);
	}
	sim(dt) {
		this.clock += dt;
		if (this.mode === "menu") return;
		if (this.mode === "over") {
			this.overT += dt;
			this.updateZone(dt);
			this.stepBots(dt, true);
			return;
		}
		this.matchTime += dt;
		this.updateZone(dt);
		this.stepPlayer(dt);
		this.stepBots(dt, false);
		this.stepBullets(dt);
		this.stepLoot();
		this.stepParticles(dt);
		this.checkEnd();
		if (this.input.mouseLooking > 0) this.input.mouseLooking -= dt;
	}
	updateZone(dt) {
		if (this.zone.phase >= ZONE_PHASES.length && !this.zone.shrinking) this.zone.dmg = ZONE_PHASES[ZONE_PHASES.length - 1]?.dmg ?? 22;
		else if (this.zone.shrinking) {
			const ph = ZONE_PHASES[this.zone.phase] ?? ZONE_PHASES[ZONE_PHASES.length - 1];
			this.zone.t -= dt;
			const dur = ph.shrink;
			const k = 1 - clamp(this.zone.t / dur, 0, 1);
			this.zone.r = this.lerp(this.zone.r, this.zone.tr, 1 - Math.exp(-dt * 1.8));
			this.zone.x = this.lerp(this.zone.x, this.zone.tx, 1 - Math.exp(-dt * 1.6));
			this.zone.z = this.lerp(this.zone.z, this.zone.tz, 1 - Math.exp(-dt * 1.6));
			this.zone.dmg = ph.dmg;
			if (k >= 1 || this.zone.t <= 0) {
				this.zone.r = this.zone.tr;
				this.zone.x = this.zone.tx;
				this.zone.z = this.zone.tz;
				this.zone.shrinking = false;
				this.zone.phase += 1;
				const next = ZONE_PHASES[this.zone.phase];
				this.zone.t = next ? next.wait : 999;
			}
		} else {
			this.zone.t -= dt;
			const ph = ZONE_PHASES[this.zone.phase];
			this.zone.dmg = ph ? ph.dmg : 22;
			if (this.zone.t <= 0 && ph) {
				this.zone.shrinking = true;
				this.zone.tr = ph.radius;
				this.zone.t = ph.shrink;
				const maxShift = Math.max(0, this.zone.r - this.zone.tr);
				const ang = this.rng() * Math.PI * 2;
				const dist = this.rng() * maxShift * .65;
				this.zone.tx = this.zone.x + Math.cos(ang) * dist;
				this.zone.tz = this.zone.z + Math.sin(ang) * dist;
				this.audio.zone();
			}
		}
		for (const a of this.actors) {
			if (!a.alive || !a.grounded) continue;
			if (Math.hypot(a.x - this.zone.x, a.z - this.zone.z) > this.zone.r - .4) this.hurt(a, this.zone.dmg * dt, -1, false);
		}
	}
	lerp(a, b, t) {
		return a + (b - a) * t;
	}
	stepPlayer(dt) {
		const p = this.actors[0];
		if (!p?.alive) return;
		const look = this.input.consumeLook();
		if (this.input.mouseLooking > 0 || this.input.pointerLocked) {
			this.camYaw -= look.dx * .0024;
			this.camPitch = clamp(this.camPitch - look.dy * .002, -1.15, .35);
		}
		const move = this.input.sampleMove();
		if (this.injectedSteer != null) this.camYaw += this.injectedSteer * 2.6 * dt;
		const cf = this.camYaw;
		const fx = -Math.sin(cf);
		const fz = -Math.cos(cf);
		const rx = Math.cos(cf);
		const rz = -Math.sin(cf);
		let wx = rx * move.x + fx * move.y;
		let wz = rz * move.x + fz * move.y;
		const wlen = Math.hypot(wx, wz);
		if (wlen > 1e-4) {
			wx /= wlen;
			wz /= wlen;
			p.yaw = Math.atan2(-wx, -wz);
		}
		if (!p.grounded) {
			p.y -= 11 * dt;
			const sp = PARA_STEER;
			p.vx = wx * sp;
			p.vz = wz * sp;
			p.x += p.vx * dt;
			p.z += p.vz * dt;
			if (p.y <= 0) {
				p.y = 0;
				p.grounded = true;
				this.burst(p.x, .4, p.z, 8, 13217914);
			}
		} else {
			const sp = PLAYER_SPEED * (move.sprint ? SPRINT_MUL : 1);
			p.vx = wx * sp;
			p.vz = wz * sp;
			p.x += p.vx * dt;
			p.z += p.vz * dt;
			this.resolve(p);
		}
		p.aimX = fx;
		p.aimZ = fz;
		if (this.input.slotQueued != null) {
			if (this.input.slotQueued === -1) p.slot = (p.slot + 1) % 2;
			else if (this.input.slotQueued < 2) p.slot = this.input.slotQueued;
			this.input.slotQueued = null;
		}
		if (this.input.reloadQueued) {
			this.startReload(p);
			this.input.reloadQueued = false;
		}
		if (this.input.interactQueued) {
			this.tryLoot(p, true);
			this.input.interactQueued = false;
		} else this.tryLoot(p, true);
		const we = WEAPONS[this.weaponOf(p)];
		if (this.input.fireHeld || this.input.fireQueued) this.tryFire(p, we.auto);
		this.input.fireQueued = false;
		if (p.reload > 0) {
			p.reload -= dt;
			if (p.reload <= 0) this.finishReload(p);
		}
		if (this.input.mouseLooking <= 0 && !this.input.pointerLocked && wlen > .15) this.camYaw = angLerp(this.camYaw, p.yaw, 1 - Math.exp(-5.5 * dt));
	}
	stepBots(dt, freezeCombat) {
		const player = this.actors[0];
		for (const a of this.actors) {
			if (a.player || !a.alive) continue;
			a.aiT -= dt;
			if (!a.grounded) {
				a.y -= 11 * .92 * dt;
				const jx = Math.sin(a.id * 1.7 + this.clock) * .4;
				const jz = Math.cos(a.id * 1.3 + this.clock) * .4;
				a.x += jx * PARA_STEER * .4 * dt;
				a.z += jz * PARA_STEER * .4 * dt;
				if (a.y <= 0) {
					a.y = 0;
					a.grounded = true;
				}
				a.mesh.position.set(a.x, a.y, a.z);
				a.mesh.rotation.y = a.yaw;
				continue;
			}
			if (a.reload > 0) {
				a.reload -= dt;
				if (a.reload <= 0) this.finishReload(a);
			}
			const inZone = Math.hypot(a.x - this.zone.x, a.z - this.zone.z) < this.zone.r - 2.5;
			if (a.aiT <= 0) {
				a.aiT = .18 + Math.random() * .12;
				const we = this.weaponOf(a);
				const armed = we !== "melee";
				let tx = a.aimX;
				let tz = a.aimZ;
				let mode = "roam";
				if (!inZone) mode = "zone";
				else if (!armed) mode = "loot";
				else {
					let best = null;
					let bestD = 42;
					for (const o of this.actors) {
						if (o === a || !o.alive || !o.grounded) continue;
						const d = Math.hypot(o.x - a.x, o.z - a.z);
						if (d < bestD) {
							bestD = d;
							best = o;
						}
					}
					if (best && bestD < (we === "sniper" ? 70 : 38)) {
						mode = "fight";
						tx = best.x;
						tz = best.z;
					} else mode = "loot";
				}
				if (mode === "zone") {
					tx = this.zone.x;
					tz = this.zone.z;
				} else if (mode === "loot") {
					let ld = 1e9;
					let lx = this.zone.x, lz = this.zone.z;
					for (const l of this.loot) {
						if (!l.live) continue;
						const d = Math.hypot(l.x - a.x, l.z - a.z);
						if (d < ld) {
							ld = d;
							lx = l.x;
							lz = l.z;
						}
					}
					tx = lx;
					tz = lz;
				}
				a.aimX = tx;
				a.aimZ = tz;
				a.ai = mode === "fight" ? 2 : mode === "zone" ? 1 : 0;
			}
			const dx = a.aimX - a.x;
			const dz = a.aimZ - a.z;
			const dist = Math.hypot(dx, dz) || 1;
			let mx = dx / dist;
			let mz = dz / dist;
			for (const o of this.actors) {
				if (o === a || !o.alive) continue;
				const sx = a.x - o.x;
				const sz = a.z - o.z;
				const sd = Math.hypot(sx, sz);
				if (sd > .01 && sd < 2.2) {
					mx += sx / sd * .55;
					mz += sz / sd * .55;
				}
			}
			const ml = Math.hypot(mx, mz) || 1;
			mx /= ml;
			mz /= ml;
			const fight = a.ai === 2;
			const sp = PLAYER_SPEED * (fight ? .78 : .92);
			if (!fight || dist > 11) {
				a.vx = mx * sp;
				a.vz = mz * sp;
			} else {
				a.vx = -mz * sp * .7;
				a.vz = mx * sp * .7;
			}
			a.x += a.vx * dt;
			a.z += a.vz * dt;
			a.yaw = Math.atan2(-mx, -mz);
			this.resolve(a);
			this.tryLoot(a, true);
			if (!freezeCombat && fight && player.alive) {
				const we = WEAPONS[this.weaponOf(a)];
				const aimDx = player.x - a.x;
				const aimDz = player.z - a.z;
				const ad = Math.hypot(aimDx, aimDz);
				if (ad < we.range * .95 && ad > 1.4 && Math.random() > .25) {
					a.yaw = Math.atan2(-aimDx, -aimDz);
					a.aimX = player.x;
					a.aimZ = player.z;
					this.tryFire(a, true);
				}
			}
		}
	}
	tryFire(a, auto) {
		const id = this.weaponOf(a);
		const we = WEAPONS[id];
		const interval = 60 / we.rpm;
		if (this.clock - a.lastShot < interval) return;
		if (a.reload > 0) return;
		if (id !== "melee" && a.mag <= 0) {
			this.startReload(a);
			return;
		}
		if (!auto && !a.player && Math.random() > .35) return;
		a.lastShot = this.clock;
		if (id !== "melee") a.mag -= 1;
		const originY = a.grounded ? 1.2 : a.y + 1.1;
		let fx, fz;
		if (a.player) {
			fx = -Math.sin(this.camYaw);
			fz = -Math.cos(this.camYaw);
		} else {
			fx = -Math.sin(a.yaw);
			fz = -Math.cos(a.yaw);
		}
		if (id === "melee") {
			this.meleeStrike(a, fx, fz, we.dmg);
			return;
		}
		if (a.player) this.audio.shoot(id === "shotgun" || id === "sniper");
		this.trauma = Math.min(1, this.trauma + (a.player ? .22 : .05));
		for (let i = 0; i < we.pellets; i++) {
			const spr = we.spread * (.4 + Math.random());
			const ang = Math.random() * Math.PI * 2;
			const sx = fx + Math.cos(ang) * spr;
			const sz = fz + Math.sin(ang) * spr;
			const sl = Math.hypot(sx, sz) || 1;
			this.spawnBullet(a, a.x + sx / sl * .8, originY, a.z + sz / sl * .8, sx / sl * we.speed, 0, sz / sl * we.speed, we.dmg, we.range / we.speed);
		}
	}
	meleeStrike(a, fx, fz, dmg) {
		for (const o of this.actors) {
			if (o === a || !o.alive) continue;
			const dx = o.x - a.x;
			const dz = o.z - a.z;
			if (Math.hypot(dx, dz) < 2.3 && dx * fx + dz * fz > 0) this.hurt(o, dmg, a.id, true);
		}
	}
	spawnBullet(owner, x, y, z, vx, vy, vz, dmg, ttl) {
		const b = this.bullets.find((q) => !q.live);
		if (!b) return;
		b.live = true;
		b.x = x;
		b.y = y;
		b.z = z;
		b.vx = vx;
		b.vy = vy;
		b.vz = vz;
		b.ttl = ttl;
		b.dmg = dmg;
		b.owner = owner.id;
		b.mesh.visible = true;
		b.mesh.material = owner.player ? this.mats.bullet : this.mats.ebullet;
	}
	stepBullets(dt) {
		for (const b of this.bullets) {
			if (!b.live) continue;
			const nx = b.x + b.vx * dt;
			const ny = b.y + b.vy * dt;
			const nz = b.z + b.vz * dt;
			if (this.hitBuild((b.x + nx) / 2, (b.z + nz) / 2, .1) || ny < .1) {
				b.live = false;
				b.mesh.visible = false;
				this.burst(nx, ny, nz, 4, 16769162);
				continue;
			}
			let hit = false;
			for (const a of this.actors) {
				if (!a.alive || a.id === b.owner) continue;
				const dy = ny - (a.y + 1);
				if (Math.hypot(nx - a.x, nz - a.z) < .62 && Math.abs(dy) < 1.15) {
					this.hurt(a, b.dmg, b.owner, true);
					hit = true;
					break;
				}
			}
			b.ttl -= dt;
			if (hit || b.ttl <= 0) {
				b.live = false;
				b.mesh.visible = false;
				if (hit) this.burst(nx, ny, nz, 6, 16746598);
				continue;
			}
			b.x = nx;
			b.y = ny;
			b.z = nz;
			b.mesh.position.set(nx, ny, nz);
		}
	}
	hurt(a, dmg, src, juice) {
		if (!a.alive || dmg <= 0) return;
		let left = dmg;
		if (a.armor > 0) {
			const use = Math.min(a.armor, left * .65);
			a.armor -= use;
			left -= use;
		}
		a.hp -= left;
		a.flash = .12;
		if (juice && a.player) {
			this.audio.hurt();
			this.trauma = Math.min(1, this.trauma + .4);
		}
		if (juice && src === 0) this.audio.hit();
		if (a.hp <= 0) {
			a.hp = 0;
			a.alive = false;
			a.mesh.visible = false;
			this.burst(a.x, 1, a.z, 16, a.color);
			const killer = this.actors[src];
			if (killer) killer.kills += 1;
			if (src === 0) {
				this.kills += 1;
				this.hitstop = .05;
				this.trauma = .7;
			}
			const kn = killer?.name ?? "ZONE";
			this.feed.unshift({
				id: ++this.feedId,
				text: `${kn}  ·  ${a.name}`,
				t: this.clock
			});
			this.feed = this.feed.slice(0, 5);
			if (a.player) {
				this.placement = this.actors.filter((x) => x.alive).length + 1;
				this.finish(false);
			}
		}
	}
	startReload(a) {
		const id = this.weaponOf(a);
		if (id === "melee") return;
		const we = WEAPONS[id];
		if (a.mag >= we.mag || a.reserve <= 0 || a.reload > 0) return;
		a.reload = 1.55;
	}
	finishReload(a) {
		const id = this.weaponOf(a);
		if (id === "melee") return;
		const need = WEAPONS[id].mag - a.mag;
		const take = Math.min(need, a.reserve);
		a.mag += take;
		a.reserve -= take;
		a.reload = 0;
	}
	tryLoot(a, pickup) {
		this.prompt = null;
		let near = null;
		let nd = 1.7;
		for (const l of this.loot) {
			if (!l.live) continue;
			const d = Math.hypot(l.x - a.x, l.z - a.z);
			if (d < nd) {
				nd = d;
				near = l;
			}
		}
		if (!near || !a.grounded) return;
		if (a.player) this.prompt = near.kind;
		if (!pickup && a.player) return;
		const kind = near.kind;
		if (kind === "med") {
			if (a.hp >= 200) return;
			a.hp = Math.min(200, a.hp + 55);
		} else if (kind === "armor") {
			if (a.armor >= 100) return;
			a.armor = Math.min(100, a.armor + 50);
		} else if (kind === "ammo") {
			const id = this.weaponOf(a);
			if (id === "melee") return;
			a.reserve += WEAPONS[id].mag * 2;
		} else {
			const empty = a.slots.findIndex((s) => s == null);
			if (empty >= 0) {
				a.slots[empty] = kind;
				a.slot = empty;
			} else a.slots[a.slot] = kind;
			const we = WEAPONS[kind];
			a.mag = we.mag;
			a.reserve = we.reserve;
		}
		near.live = false;
		near.mesh.visible = false;
		if (a.player) this.audio.pickup();
	}
	checkEnd() {
		if (this.actors.filter((a) => a.alive).length <= 1 && this.mode === "playing") {
			if (this.actors[0].alive) {
				this.placement = 1;
				this.finish(true);
			}
		}
	}
	finish(won) {
		if (this.mode !== "playing") return;
		this.mode = "over";
		this.won = won;
		this.overT = 0;
		if (won) this.audio.win();
		else this.audio.lose();
		this.onOver(won, this.placement, this.kills);
		this.pushHud(true);
	}
	burst(x, y, z, n, _color) {
		let c = 0;
		for (const p of this.particles) {
			if (p.t > 0) continue;
			p.t = .35 + Math.random() * .2;
			p.m.visible = true;
			p.m.position.set(x, y, z);
			p.vx = (Math.random() - .5) * 6;
			p.vy = 2 + Math.random() * 5;
			p.vz = (Math.random() - .5) * 6;
			c++;
			if (c >= n) break;
		}
	}
	stepParticles(dt) {
		for (const p of this.particles) {
			if (p.t <= 0) continue;
			p.t -= dt;
			p.vy -= 12 * dt;
			p.m.position.x += p.vx * dt;
			p.m.position.y += p.vy * dt;
			p.m.position.z += p.vz * dt;
			if (p.t <= 0 || p.m.position.y < 0) {
				p.t = 0;
				p.m.visible = false;
			}
		}
	}
	stepLoot() {
		const t = this.clock;
		for (const l of this.loot) {
			if (!l.live) continue;
			l.mesh.position.y = .32 + Math.sin(t * 2.5 + l.x) * .08;
			l.mesh.rotation.y += .01;
		}
	}
	orbitMenu(dt) {
		this.camYaw += dt * .12;
		const r = 48;
		this.camera.position.set(Math.sin(this.camYaw) * r, 22, Math.cos(this.camYaw) * r);
		this.camera.lookAt(0, 1, 0);
	}
	draw(dt) {
		this.trauma = Math.max(0, this.trauma - dt * 1.6);
		const shake = this.trauma * this.trauma;
		if (this.mode === "menu") this.orbitMenu(dt);
		else {
			const p = this.actors[0];
			const dist = p.grounded ? 6.8 : 11;
			const height = p.grounded ? 3.1 : 5.5;
			const fx = -Math.sin(this.camYaw);
			const fz = -Math.cos(this.camYaw);
			const rx = Math.cos(this.camYaw);
			const rz = -Math.sin(this.camYaw);
			const tx = p.x + rx * .55;
			const tz = p.z + rz * .55;
			const desired = this.tmp.set(tx - fx * dist, p.y + height - this.camPitch * 2.4, tz - fz * dist);
			this.camera.position.lerp(desired, 1 - Math.exp(-8 * dt));
			this.tmp2.set(p.x, p.y + 1.25, p.z);
			this.camera.lookAt(this.tmp2);
			if (shake > .002) {
				this.camera.position.x += (Math.random() - .5) * shake * .45;
				this.camera.position.y += (Math.random() - .5) * shake * .3;
			}
		}
		for (const a of this.actors) {
			if (!a.alive) continue;
			a.mesh.position.set(a.x, a.y, a.z);
			a.mesh.rotation.y = a.yaw;
			if (a.flash > 0) {
				a.flash -= dt;
				a.bodyMat.emissive.setHex(a.flash > 0 ? 4465152 : 0);
			}
		}
		this.zoneRing.position.set(this.zone.x, .08, this.zone.z);
		const zs = Math.max(.05, this.zone.r / 86);
		this.zoneRing.scale.set(zs, 1, zs);
		this.zoneWall.position.set(this.zone.x, 9, this.zone.z);
		this.zoneWall.scale.set(zs, 1, zs);
		if (this.mode === "playing") {
			this.planeMesh.position.x += 28 * dt;
			this.planeMesh.visible = this.planeMesh.position.x < 100;
		}
		this.renderer.render(this.scene, this.camera);
	}
	wireProbe() {
		window.__controlsTest = {
			getYaw: () => this.actors[0]?.yaw ?? 0,
			getSpeed: () => {
				const p = this.actors[0];
				if (!p) return 0;
				return Math.hypot(p.vx, p.vz);
			},
			setKeys: (codes) => this.input.setKeys(codes),
			setSteer: (v) => {
				this.injectedSteer = v === 0 ? null : v;
			}
		};
	}
	pushHud(force) {
		const p = this.actors[0];
		if (!p && !force) return;
		const weId = p ? this.weaponOf(p) : "melee";
		const we = WEAPONS[weId];
		const alive = this.actors.filter((a) => a.alive).length;
		const snap = {
			hp: p?.hp ?? 0,
			maxHp: 200,
			armor: p?.armor ?? 0,
			mag: p?.mag ?? 0,
			magSize: we.mag,
			reserve: p?.reserve ?? 0,
			weapon: weId,
			weaponName: we.name,
			weaponNameAr: we.nameAr,
			alive,
			kills: this.kills,
			zoneIn: p ? Math.hypot(p.x - this.zone.x, p.z - this.zone.z) < this.zone.r - .5 : true,
			zoneDmg: this.zone.dmg,
			zoneEta: this.zone.t,
			shrinking: this.zone.shrinking,
			prompt: this.prompt,
			grounded: p?.grounded ?? true,
			reloading: (p?.reload ?? 0) > 0,
			feed: this.feed,
			posX: p?.x ?? 0,
			posZ: p?.z ?? 0,
			yaw: p?.yaw ?? 0,
			others: this.actors.filter((a) => a.alive).map((a) => ({
				x: a.x,
				z: a.z,
				self: a.player
			})),
			zoneX: this.zone.x,
			zoneZ: this.zone.z,
			zoneR: this.zone.r,
			nextR: this.zone.tr,
			mapR: 86,
			placement: this.placement,
			won: this.won,
			slots: [0, 1].map((i) => {
				const id = p?.slots[i] ?? null;
				return {
					id,
					name: id ? WEAPONS[id].name : "—"
				};
			}),
			slot: p?.slot ?? 0,
			matchTime: this.matchTime
		};
		this.onHud(snap);
	}
};
//#endregion
export { BlazeGame };
