//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ZR4iTgrB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BBszXmuo.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BBszXmuo.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DwjR9x5L.js"]
	}
} });
//#endregion
export { tsrStartManifest };
