import type { WeaponId } from "./config";

export type Screen = "menu" | "playing" | "over";

export type KillFeedItem = { id: number; text: string; t: number };

export type HudSnapshot = {
  hp: number;
  maxHp: number;
  armor: number;
  mag: number;
  magSize: number;
  reserve: number;
  weapon: WeaponId;
  weaponName: string;
  weaponNameAr: string;
  alive: number;
  kills: number;
  zoneIn: boolean;
  zoneDmg: number;
  zoneEta: number;
  shrinking: boolean;
  prompt: string | null;
  grounded: boolean;
  reloading: boolean;
  feed: KillFeedItem[];
  posX: number;
  posZ: number;
  yaw: number;
  others: { x: number; z: number; self?: boolean }[];
  zoneX: number;
  zoneZ: number;
  zoneR: number;
  nextR: number;
  mapR: number;
  placement: number;
  won: boolean;
  slots: { id: WeaponId | null; name: string }[];
  slot: number;
  matchTime: number;
};

export type Stats = {
  name: string;
  matches: number;
  wins: number;
  kills: number;
  best: number;
};
