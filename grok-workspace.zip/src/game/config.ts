export const MAP_R = 86;
export const PLAYER_COUNT = 16;
export const FIXED_DT = 1 / 60;
export const PLAYER_SPEED = 9.4;
export const SPRINT_MUL = 1.22;
export const ACTOR_RADIUS = 0.46;
export const PARA_FALL = 11;
export const PARA_STEER = 13.5;

export type WeaponId = "melee" | "pistol" | "smg" | "ar" | "shotgun" | "sniper";
export type LootKind = WeaponId | "ammo" | "med" | "armor";

export type WeaponDef = {
  id: WeaponId;
  name: string;
  nameAr: string;
  dmg: number;
  rpm: number;
  mag: number;
  reserve: number;
  spread: number;
  range: number;
  speed: number;
  pellets: number;
  auto: boolean;
  color: number;
};

export const WEAPONS: Record<WeaponId, WeaponDef> = {
  melee: {
    id: "melee",
    name: "Blade",
    nameAr: "شفرة",
    dmg: 42,
    rpm: 110,
    mag: 0,
    reserve: 0,
    spread: 0,
    range: 2.3,
    speed: 0,
    pellets: 1,
    auto: false,
    color: 0xc4c0b8,
  },
  pistol: {
    id: "pistol",
    name: "Vesper",
    nameAr: "فسبر",
    dmg: 26,
    rpm: 240,
    mag: 12,
    reserve: 48,
    spread: 0.032,
    range: 46,
    speed: 96,
    pellets: 1,
    auto: false,
    color: 0xd8c07a,
  },
  smg: {
    id: "smg",
    name: "Wasp",
    nameAr: "واسب",
    dmg: 15,
    rpm: 780,
    mag: 30,
    reserve: 90,
    spread: 0.068,
    range: 36,
    speed: 90,
    pellets: 1,
    auto: true,
    color: 0x7ad0c8,
  },
  ar: {
    id: "ar",
    name: "Ember-4",
    nameAr: "إمبر-4",
    dmg: 24,
    rpm: 580,
    mag: 30,
    reserve: 90,
    spread: 0.04,
    range: 64,
    speed: 118,
    pellets: 1,
    auto: true,
    color: 0xe85d04,
  },
  shotgun: {
    id: "shotgun",
    name: "Breach",
    nameAr: "بريتش",
    dmg: 13,
    rpm: 78,
    mag: 5,
    reserve: 20,
    spread: 0.19,
    range: 15,
    speed: 74,
    pellets: 6,
    auto: false,
    color: 0xc45c5c,
  },
  sniper: {
    id: "sniper",
    name: "Longmark",
    nameAr: "لونغ مارك",
    dmg: 88,
    rpm: 46,
    mag: 5,
    reserve: 15,
    spread: 0.006,
    range: 130,
    speed: 170,
    pellets: 1,
    auto: false,
    color: 0x6ea8e8,
  },
};

export const ZONE_PHASES = [
  { wait: 22, shrink: 16, radius: 86, dmg: 2 },
  { wait: 16, shrink: 14, radius: 54, dmg: 4 },
  { wait: 13, shrink: 12, radius: 30, dmg: 8 },
  { wait: 11, shrink: 10, radius: 15, dmg: 14 },
  { wait: 9, shrink: 9, radius: 6, dmg: 22 },
];

export const BOT_NAMES = [
  "KARIM",
  "NOVA",
  "RAZE",
  "MIRA",
  "FALCON",
  "ZED",
  "LAYLA",
  "GHOST",
  "OMAR",
  "NICO",
  "SABLE",
  "YARA",
  "REX",
  "DUSK",
  "KAI",
];

export const BOT_COLORS = [
  0x2f6fed, 0xc43b6f, 0x2fa36a, 0x8b5cff, 0xd9a21b, 0x1aa7a1, 0xd4542a, 0x4d7c9e,
  0xb85ad4, 0x5c8a3a, 0xcf4d4d, 0x3d6dcc, 0xa67c52, 0x6e6e78, 0xe07aad,
];

export const STATS_KEY = "blaze-drop-stats-v1";
export const NAME_KEY = "blaze-drop-name";
export const LANG_KEY = "blaze-drop-lang";
