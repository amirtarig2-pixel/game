const GAME_CODES = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "Space",
  "KeyR",
  "KeyF",
  "KeyE",
  "ShiftLeft",
  "ShiftRight",
  "Digit1",
  "Digit2",
  "Digit3",
  "KeyQ",
]);

export class GameInput {
  keys = new Set<string>();
  injected: string[] | null = null;
  lookDx = 0;
  lookDy = 0;
  fireHeld = false;
  fireQueued = false;
  reloadQueued = false;
  interactQueued = false;
  joyX = 0;
  joyY = 0;
  lookStickX = 0;
  lookStickY = 0;
  slotQueued: number | null = null;
  mouseLooking = 0;
  pointerLocked = false;

  attach() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.clear);
    document.addEventListener("visibilitychange", this.onVis);
    window.addEventListener("mousemove", this.onMouse, true);
    window.addEventListener("mousedown", this.onMouseDown, true);
    window.addEventListener("mouseup", this.onMouseUp, true);
    document.addEventListener("pointerlockchange", this.onLock);
  }

  detach() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.clear);
    document.removeEventListener("visibilitychange", this.onVis);
    window.removeEventListener("mousemove", this.onMouse, true);
    window.removeEventListener("mousedown", this.onMouseDown, true);
    window.removeEventListener("mouseup", this.onMouseUp, true);
    document.removeEventListener("pointerlockchange", this.onLock);
  }

  private onLock = () => {
    this.pointerLocked = document.pointerLockElement != null;
  };

  private onKeyDown = (e: KeyboardEvent) => {
    if (GAME_CODES.has(e.code)) e.preventDefault();
    this.keys.add(e.code);
    if (e.code === "KeyR") this.reloadQueued = true;
    if (e.code === "KeyF" || e.code === "KeyE") this.interactQueued = true;
    if (e.code === "Digit1") this.slotQueued = 0;
    if (e.code === "Digit2") this.slotQueued = 1;
    if (e.code === "Digit3") this.slotQueued = 2;
    if (e.code === "KeyQ") this.slotQueued = -1;
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onVis = () => {
    if (document.hidden) this.clear();
  };

  private onMouse = (e: MouseEvent) => {
    if (!this.pointerLocked && e.buttons === 0) return;
    this.lookDx += e.movementX;
    this.lookDy += e.movementY;
    this.mouseLooking = 0.45;
  };

  private onMouseDown = (e: MouseEvent) => {
    if (e.button === 0) {
      this.fireHeld = true;
      this.fireQueued = true;
    }
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) this.fireHeld = false;
  };

  clear = () => {
    this.keys.clear();
    this.fireHeld = false;
    this.joyX = 0;
    this.joyY = 0;
  };

  setKeys(codes: string[]) {
    this.injected = codes.length ? [...codes] : null;
  }

  down(code: string) {
    if (this.injected) return this.injected.includes(code);
    return this.keys.has(code);
  }

  sampleMove(): { x: number; y: number; sprint: boolean } {
    let x = this.joyX;
    let y = this.joyY;
    if (this.down("KeyA") || this.down("ArrowLeft")) x -= 1;
    if (this.down("KeyD") || this.down("ArrowRight")) x += 1;
    if (this.down("KeyW") || this.down("ArrowUp")) y += 1;
    if (this.down("KeyS") || this.down("ArrowDown")) y -= 1;
    this.pollGamepad();
    let padFire = false;
    const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : [];
    if (pads) {
      for (const p of pads) {
        if (!p || p.mapping !== "standard") continue;
        x += this.dead(p.axes[0] ?? 0, p.axes[1] ?? 0).x;
        y -= this.dead(p.axes[0] ?? 0, p.axes[1] ?? 0).y;
        const look = this.dead(p.axes[2] ?? 0, p.axes[3] ?? 0, 0.18);
        this.lookDx += look.x * 14;
        this.lookDy += look.y * 10;
        if (p.buttons[7]?.value && p.buttons[7].value > 0.4) {
          padFire = true;
        }
      }
    }
    if (padFire) {
      this.fireHeld = true;
      this.fireQueued = true;
    }
    const len = Math.hypot(x, y);
    if (len > 1) {
      x /= len;
      y /= len;
    }
    const sprint = this.down("ShiftLeft") || this.down("ShiftRight");
    return { x, y, sprint };
  }

  consumeLook() {
    const dx = this.lookDx + this.lookStickX * 10;
    const dy = this.lookDy + this.lookStickY * 8;
    this.lookDx = 0;
    this.lookDy = 0;
    return { dx, dy };
  }

  private dead(x: number, y: number, dz = 0.16) {
    const m = Math.hypot(x, y);
    if (m < dz) return { x: 0, y: 0 };
    const scale = (m - dz) / (1 - dz) / m;
    return { x: x * scale, y: y * scale };
  }

  private pollGamepad() {
    // sampled in sampleMove
  }
}
