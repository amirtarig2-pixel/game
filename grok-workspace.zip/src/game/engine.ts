import * as THREE from "three";
import { GameAudio } from "./audio";
import {
  ACTOR_RADIUS,
  BOT_COLORS,
  BOT_NAMES,
  FIXED_DT,
  MAP_R,
  PARA_FALL,
  PARA_STEER,
  PLAYER_COUNT,
  PLAYER_SPEED,
  SPRINT_MUL,
  WEAPONS,
  ZONE_PHASES,
  type WeaponId,
} from "./config";
import { GameInput } from "./input";
import type { HudSnapshot, KillFeedItem } from "./types";

type WeaponIdOrNone = WeaponId;

type Actor = {
  id: number;
  name: string;
  player: boolean;
  x: number;
  y: number;
  z: number;
  yaw: number;
  vx: number;
  vz: number;
  hp: number;
  armor: number;
  alive: boolean;
  grounded: boolean;
  slots: (WeaponId | null)[];
  slot: number;
  mag: number;
  reserve: number;
  lastShot: number;
  reload: number;
  color: number;
  mesh: THREE.Group;
  bodyMat: THREE.MeshLambertMaterial;
  gunMesh: THREE.Group;
  ai: number;
  aiT: number;
  aimX: number;
  aimZ: number;
  flash: number;
  kills: number;
};

type Loot = {
  kind: WeaponId | "ammo" | "med" | "armor";
  x: number;
  z: number;
  mesh: THREE.Object3D;
  live: boolean;
};

type Bullet = {
  live: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  ttl: number;
  dmg: number;
  owner: number;
  mesh: THREE.Mesh;
};

type Building = { minX: number; maxX: number; minZ: number; maxZ: number; h: number };

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a += 0x6d2b79f5;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function angLerp(a: number, b: number, t: number) {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v));
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setSteer?: (v: number) => void;
      setKeys?: (codes: string[]) => void;
    };
  }
}

export class BlazeGame {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(62, 1, 0.12, 420);
  input = new GameInput();
  audio = new GameAudio();
  mode: "menu" | "playing" | "over" = "menu";
  playerName = "YOU";
  lang: "ar" | "en" = "ar";

  actors: Actor[] = [];
  loot: Loot[] = [];
  bullets: Bullet[] = [];
  buildings: Building[] = [];
  zone = { x: 0, z: 0, r: MAP_R, tx: 0, tz: 0, tr: MAP_R, phase: 0, t: 0, shrinking: false, dmg: 0 };
  feed: KillFeedItem[] = [];
  feedId = 0;
  kills = 0;
  matchTime = 0;
  overT = 0;
  won = false;
  placement = PLAYER_COUNT;
  camYaw = 0;
  camPitch = -0.28;
  trauma = 0;
  hitstop = 0;
  clock = 0;
  acc = 0;
  hudAcc = 0;
  last = 0;
  raf = 0;
  alive = true;
  onHud: (h: HudSnapshot) => void;
  onOver: (won: boolean, place: number, kills: number) => void;
  shared: Record<string, THREE.BufferGeometry>;
  mats: Record<string, THREE.Material>;
  zoneRing: THREE.Mesh;
  zoneWall: THREE.Mesh;
  planeMesh: THREE.Group;
  particles: { m: THREE.Mesh; vx: number; vy: number; vz: number; t: number }[] = [];
  spawnPlane = { x: -90, z: 0, a: 0 };
  tmp = new THREE.Vector3();
  tmp2 = new THREE.Vector3();
  injectedSteer: number | null = null;
  prompt: string | null = null;
  observer: ResizeObserver | null = null;

  constructor(
    canvas: HTMLCanvasElement,
    hooks: {
      onHud: (h: HudSnapshot) => void;
      onOver: (won: boolean, place: number, kills: number) => void;
    },
  ) {
    this.onHud = hooks.onHud;
    this.onOver = hooks.onOver;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.renderer.setClearColor(0x6ea8c8, 1);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = false;
    this.scene.fog = new THREE.Fog(0x7eafc4, 48, 210);
    this.shared = {
      body: new THREE.CapsuleGeometry(0.32, 0.64, 3, 8),
      head: new THREE.SphereGeometry(0.26, 8, 6),
      pack: new THREE.BoxGeometry(0.32, 0.38, 0.16),
      visor: new THREE.BoxGeometry(0.28, 0.1, 0.08),
      gun: new THREE.BoxGeometry(0.08, 0.1, 0.7),
      barrel: new THREE.BoxGeometry(0.05, 0.05, 0.28),
      mag: new THREE.BoxGeometry(0.07, 0.16, 0.12),
      crate: new THREE.BoxGeometry(0.7, 0.55, 0.7),
      bullet: new THREE.SphereGeometry(0.08, 6, 4),
      particle: new THREE.SphereGeometry(0.07, 5, 4),
      blob: new THREE.CircleGeometry(0.55, 10),
      canopy: new THREE.ConeGeometry(1.35, 2.6, 7),
      trunk: new THREE.CylinderGeometry(0.16, 0.22, 1.4, 5),
      rock: new THREE.DodecahedronGeometry(0.9, 0),
    };
    this.mats = {
      grass: new THREE.MeshLambertMaterial({ vertexColors: true }),
      sand: new THREE.MeshLambertMaterial({ color: 0xc9b07a }),
      water: new THREE.MeshLambertMaterial({ color: 0x2a7ea8, transparent: true, opacity: 0.92 }),
      roof: new THREE.MeshLambertMaterial({ color: 0x6a4030 }),
      wall: new THREE.MeshLambertMaterial({ color: 0xc8bca8 }),
      wall2: new THREE.MeshLambertMaterial({ color: 0x8f9aa3 }),
      crate: new THREE.MeshLambertMaterial({ color: 0xc45a16 }),
      trunk: new THREE.MeshLambertMaterial({ color: 0x5a3a22 }),
      canopy: new THREE.MeshLambertMaterial({ color: 0x1f6b3a }),
      canopy2: new THREE.MeshLambertMaterial({ color: 0x2d8a4a }),
      rock: new THREE.MeshLambertMaterial({ color: 0x7a756c }),
      zone: new THREE.MeshBasicMaterial({ color: 0x5ee0c0, transparent: true, opacity: 0.22, side: THREE.DoubleSide }),
      wallZone: new THREE.MeshBasicMaterial({ color: 0x5ee0c0, transparent: true, opacity: 0.07, side: THREE.DoubleSide }),
      bullet: new THREE.MeshBasicMaterial({ color: 0xffe08a }),
      ebullet: new THREE.MeshBasicMaterial({ color: 0xff6a5a }),
      blob: new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28, depthWrite: false }),
      particle: new THREE.MeshBasicMaterial({ color: 0xffb070 }),
    };

    this.buildWorld();
    this.zoneRing = new THREE.Mesh(new THREE.RingGeometry(85.2, 86.4, 64), this.mats.zone);
    this.zoneRing.rotation.x = -Math.PI / 2;
    this.zoneRing.position.y = 0.08;
    this.scene.add(this.zoneRing);
    this.zoneWall = new THREE.Mesh(new THREE.CylinderGeometry(86, 86, 18, 64, 1, true), this.mats.wallZone);
    this.zoneWall.position.y = 9;
    this.scene.add(this.zoneWall);

    this.planeMesh = new THREE.Group();
    const fus = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.7, 8.5), new THREE.MeshLambertMaterial({ color: 0xd8d2c6 }));
    const wing = new THREE.Mesh(new THREE.BoxGeometry(11, 0.12, 2.2), new THREE.MeshLambertMaterial({ color: 0xe85d04 }));
    wing.position.y = 0.1;
    this.planeMesh.add(fus, wing);
    this.planeMesh.position.set(-120, 36, 0);
    this.scene.add(this.planeMesh);

    this.makeBulletPool();
    this.makeParticlePool();
    this.resize();
    this.resize();
    this.observer = new ResizeObserver(() => this.resize());
    this.observer.observe(canvas.parentElement ?? canvas);
    requestAnimationFrame(() => this.resize());
    this.input.attach();
    this.last = performance.now();
    this.loop = this.loop.bind(this);
    this.raf = requestAnimationFrame(this.loop);
    window.addEventListener("resize", this.resize);
    this.wireProbe();
    this.orbitMenu(0);
    this.pushHud(true);
  }

  destroy() {
    this.alive = false;
    cancelAnimationFrame(this.raf);
    this.observer?.disconnect();
    window.removeEventListener("resize", this.resize);
    this.input.detach();
    if (window.__controlsTest) delete window.__controlsTest;
    this.renderer.dispose();
    for (const g of Object.values(this.shared)) g.dispose();
    for (const m of Object.values(this.mats)) m.dispose();
  }

  setName(n: string) {
    this.playerName = n.slice(0, 14) || "YOU";
    const p = this.actors.find((a) => a.player);
    if (p) p.name = this.playerName;
  }

  resize = () => {
    const c = this.renderer.domElement;
    const parent = c.parentElement;
    const w = Math.max(1, parent?.clientWidth || c.clientWidth || window.innerWidth);
    const h = Math.max(1, parent?.clientHeight || c.clientHeight || window.innerHeight);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  startMatch(name: string) {
    this.playerName = name.slice(0, 14) || "YOU";
    this.audio.unlock();
    this.mode = "playing";
    this.kills = 0;
    this.matchTime = 0;
    this.won = false;
    this.overT = 0;
    this.feed = [];
    this.camYaw = 0;
    this.camPitch = -0.32;
    this.trauma = 0;
    this.zone = { x: 0, z: 0, r: MAP_R, tx: 0, tz: 0, tr: MAP_R, phase: 0, t: ZONE_PHASES[0].wait, shrinking: false, dmg: 0 };
    this.resetActors();
    this.respawnLoot();
    for (const b of this.bullets) b.live = false;
    this.spawnPlane = { x: -92, z: (this.rng() - 0.5) * 20, a: 0 };
    this.planeMesh.position.set(this.spawnPlane.x, 34, this.spawnPlane.z);
    this.planeMesh.rotation.y = Math.PI / 2;
    this.wireProbe();
    this.pushHud(true);
  }

  rng = mulberry(0xc1d7e5);

  private buildWorld() {
    const hemi = new THREE.HemisphereLight(0xcfe8ff, 0x3d5a32, 1.05);
    const sun = new THREE.DirectionalLight(0xfff1d6, 1.15);
    sun.position.set(-40, 70, 22);
    this.scene.add(hemi, sun);

    const water = new THREE.Mesh(new THREE.CircleGeometry(MAP_R + 48, 48), this.mats.water);
    water.rotation.x = -Math.PI / 2;
    water.position.y = -0.25;
    this.scene.add(water);

    const groundGeo = new THREE.CircleGeometry(MAP_R + 2, 96);
    const pos = groundGeo.attributes.position;
    const colors = new Float32Array(pos.count * 3);
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getY(i);
      const r = Math.hypot(x, z);
      const n = Math.sin(x * 0.12) * Math.cos(z * 0.11) + Math.sin(x * 0.41 + z * 0.2) * 0.35;
      if (r > MAP_R - 7) c.set(0xd2b57a);
      else if (n > 0.55) c.set(0x4a7a32);
      else if (n < -0.45) c.set(0x6b5a38);
      else c.set(0x3f7a3a);
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    groundGeo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    groundGeo.rotateX(-Math.PI / 2);
    const ground = new THREE.Mesh(groundGeo, this.mats.grass);
    this.scene.add(ground);

    this.placeTown(-28, -8, "Port");
    this.placeTown(32, 18, "Ruins");
    this.placeTown(6, -36, "Camp");
    this.placeTown(-12, 38, "Ridge");
    this.scatterNature();
  }

  private placeTown(cx: number, cz: number, _name: string) {
    const n = 5 + Math.floor(this.rng() * 3);
    for (let i = 0; i < n; i++) {
      const w = 4.2 + this.rng() * 5.5;
      const d = 3.6 + this.rng() * 5;
      const h = 3.2 + this.rng() * 4.4;
      const x = cx + (this.rng() - 0.5) * 22;
      const z = cz + (this.rng() - 0.5) * 22;
      if (Math.hypot(x, z) > MAP_R - 10) continue;
      const wallMat = this.rng() > 0.5 ? this.mats.wall : this.mats.wall2;
      const box = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMat);
      box.position.set(x, h / 2, z);
      const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 0.4, 0.28, d + 0.4), this.mats.roof);
      roof.position.set(x, h + 0.12, z);
      this.scene.add(box, roof);
      this.buildings.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2, h });
    }
  }

  private scatterNature() {
    const canopy = new THREE.InstancedMesh(this.shared.canopy, this.mats.canopy, 70);
    const trunk = new THREE.InstancedMesh(this.shared.trunk, this.mats.trunk, 70);
    const dummy = new THREE.Object3D();
    let placed = 0;
    let guard = 0;
    while (placed < 70 && guard < 400) {
      guard++;
      const a = this.rng() * Math.PI * 2;
      const r = 8 + this.rng() * (MAP_R - 14);
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      if (this.hitBuild(x, z, 1.6)) continue;
      dummy.position.set(x, 2.3, z);
      dummy.rotation.y = this.rng() * 6;
      dummy.scale.setScalar(0.75 + this.rng() * 0.6);
      dummy.updateMatrix();
      canopy.setMatrixAt(placed, dummy.matrix);
      dummy.position.set(x, 0.7, z);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      trunk.setMatrixAt(placed, dummy.matrix);
      placed++;
    }
    this.scene.add(canopy, trunk);

    const rocks = new THREE.InstancedMesh(this.shared.rock, this.mats.rock, 28);
    for (let i = 0; i < 28; i++) {
      const a = this.rng() * Math.PI * 2;
      const r = 10 + this.rng() * (MAP_R - 8);
      dummy.position.set(Math.cos(a) * r, 0.2, Math.sin(a) * r);
      dummy.rotation.set(this.rng(), this.rng(), this.rng());
      dummy.scale.setScalar(0.5 + this.rng() * 1.1);
      dummy.updateMatrix();
      rocks.setMatrixAt(i, dummy.matrix);
    }
    this.scene.add(rocks);
  }

  private makeActor(id: number, name: string, color: number, player: boolean): Actor {
    const g = new THREE.Group();
    const bodyMat = new THREE.MeshLambertMaterial({ color });
    const dark = new THREE.MeshLambertMaterial({ color: 0x1a1c20 });
    const skin = new THREE.MeshLambertMaterial({ color: 0xe0b089 });
    const body = new THREE.Mesh(this.shared.body, bodyMat);
    body.position.y = 0.9;
    const head = new THREE.Mesh(this.shared.head, skin);
    head.position.y = 1.54;
    const visor = new THREE.Mesh(this.shared.visor, dark);
    visor.position.set(0, 1.56, -0.18);
    const pack = new THREE.Mesh(this.shared.pack, dark);
    pack.position.set(0, 1.05, 0.28);
    const gun = new THREE.Group();
    const gb = new THREE.Mesh(this.shared.gun, dark);
    const barrel = new THREE.Mesh(this.shared.barrel, dark);
    barrel.position.z = -0.46;
    const mag = new THREE.Mesh(this.shared.mag, dark);
    mag.position.set(0, -0.12, 0.05);
    gun.add(gb, barrel, mag);
    gun.position.set(0.28, 1.05, -0.35);
    const blob = new THREE.Mesh(this.shared.blob, this.mats.blob);
    blob.rotation.x = -Math.PI / 2;
    blob.position.y = 0.03;
    g.add(body, head, visor, pack, gun, blob);
    this.scene.add(g);
    return {
      id,
      name,
      player,
      x: 0,
      y: 28,
      z: 0,
      yaw: 0,
      vx: 0,
      vz: 0,
      hp: 200,
      armor: 0,
      alive: true,
      grounded: false,
      slots: [null, null],
      slot: 0,
      mag: 0,
      reserve: 0,
      lastShot: 0,
      reload: 0,
      color,
      mesh: g,
      bodyMat,
      gunMesh: gun,
      ai: 0,
      aiT: 0,
      aimX: 0,
      aimZ: -1,
      flash: 0,
      kills: 0,
    };
  }

  private resetActors() {
    for (const a of this.actors) this.scene.remove(a.mesh);
    this.actors = [];
    const p = this.makeActor(0, this.playerName, 0xe85d04, true);
    this.actors.push(p);
    for (let i = 1; i < PLAYER_COUNT; i++) {
      this.actors.push(this.makeActor(i, BOT_NAMES[i - 1] ?? `P${i}`, BOT_COLORS[(i - 1) % BOT_COLORS.length], false));
    }
    const dropZ = (this.rng() - 0.5) * 18;
    for (let i = 0; i < this.actors.length; i++) {
      const a = this.actors[i];
      a.x = -40 - this.rng() * 30 + (this.rng() - 0.5) * 8;
      a.z = dropZ + (i - 8) * 2.4 + (this.rng() - 0.5) * 6;
      a.y = 26 + this.rng() * 6;
      a.yaw = Math.PI / 2;
      a.grounded = false;
      a.alive = true;
      a.hp = 200;
      a.armor = 0;
      a.slots = [null, null];
      a.slot = 0;
      a.mag = 0;
      a.reserve = 0;
      a.mesh.visible = true;
    }
  }

  private respawnLoot() {
    for (const l of this.loot) this.scene.remove(l.mesh);
    this.loot = [];
    const kinds: Loot["kind"][] = [
      "pistol",
      "pistol",
      "smg",
      "smg",
      "smg",
      "ar",
      "ar",
      "ar",
      "ar",
      "shotgun",
      "shotgun",
      "sniper",
      "sniper",
      "ammo",
      "ammo",
      "ammo",
      "ammo",
      "ammo",
      "med",
      "med",
      "med",
      "med",
      "armor",
      "armor",
      "armor",
      "pistol",
      "ar",
      "smg",
      "ammo",
      "med",
    ];
    const dummyKinds = [...kinds];
    while (dummyKinds.length < 56) dummyKinds.push(this.rng() > 0.5 ? "ammo" : "med");
    for (const kind of dummyKinds) {
      let x = 0,
        z = 0,
        ok = false;
      for (let t = 0; t < 12; t++) {
        const a = this.rng() * Math.PI * 2;
        const r = 6 + this.rng() * (MAP_R - 12);
        x = Math.cos(a) * r;
        z = Math.sin(a) * r;
        if (!this.hitBuild(x, z, 1.2)) {
          ok = true;
          break;
        }
      }
      if (!ok) continue;
      const isGun = kind in WEAPONS && kind !== "melee";
      const mesh = new THREE.Mesh(
        this.shared.crate,
        new THREE.MeshLambertMaterial({
          color: isGun ? WEAPONS[kind as WeaponId].color : kind === "med" ? 0x3ecf6e : kind === "armor" ? 0x4aa3e8 : 0xd8c07a,
        }),
      );
      mesh.position.set(x, 0.32, z);
      this.scene.add(mesh);
      this.loot.push({ kind, x, z, mesh, live: true });
    }
  }

  private makeBulletPool() {
    for (let i = 0; i < 80; i++) {
      const mesh = new THREE.Mesh(this.shared.bullet, this.mats.bullet);
      mesh.visible = false;
      this.scene.add(mesh);
      this.bullets.push({ live: false, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, ttl: 0, dmg: 0, owner: 0, mesh });
    }
  }

  private makeParticlePool() {
    for (let i = 0; i < 64; i++) {
      const m = new THREE.Mesh(this.shared.particle, this.mats.particle);
      m.visible = false;
      this.scene.add(m);
      this.particles.push({ m, vx: 0, vy: 0, vz: 0, t: 0 });
    }
  }

  private hitBuild(x: number, z: number, r: number) {
    for (const b of this.buildings) {
      if (x + r > b.minX && x - r < b.maxX && z + r > b.minZ && z - r < b.maxZ) return b;
    }
    return null;
  }

  private resolve(a: Actor, r = ACTOR_RADIUS) {
    for (const b of this.buildings) {
      if (a.y > b.h + 0.4) continue;
      const cx = clamp(a.x, b.minX, b.maxX);
      const cz = clamp(a.z, b.minZ, b.maxZ);
      const dx = a.x - cx;
      const dz = a.z - cz;
      const d = Math.hypot(dx, dz);
      if (d < r && d > 1e-4) {
        const p = (r - d) / d;
        a.x += dx * p;
        a.z += dz * p;
      } else if (d < 1e-4) {
        a.x += r;
      }
    }
    const md = Math.hypot(a.x, a.z);
    if (md > MAP_R - 1.2) {
      const s = (MAP_R - 1.2) / md;
      a.x *= s;
      a.z *= s;
    }
  }

  private weaponOf(a: Actor): WeaponIdOrNone {
    return a.slots[a.slot] ?? "melee";
  }

  private loop(now: number) {
    if (!this.alive) return;
    const raw = Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    this.acc += raw;
    while (this.acc >= FIXED_DT) {
      if (this.hitstop > 0) this.hitstop -= FIXED_DT;
      else this.sim(FIXED_DT);
      this.acc -= FIXED_DT;
    }
    this.draw(raw);
    this.hudAcc += raw;
    if (this.hudAcc > 0.09) {
      this.hudAcc = 0;
      this.pushHud(false);
    }
    this.raf = requestAnimationFrame(this.loop);
  }

  private sim(dt: number) {
    this.clock += dt;
    if (this.mode === "menu") return;
    if (this.mode === "over") {
      this.overT += dt;
      this.updateZone(dt);
      this.stepBots(dt, true);
      return;
    }
    this.matchTime += dt;
    this.updateZone(dt);
    this.stepPlayer(dt);
    this.stepBots(dt, false);
    this.stepBullets(dt);
    this.stepLoot();
    this.stepParticles(dt);
    this.checkEnd();
    if (this.input.mouseLooking > 0) this.input.mouseLooking -= dt;
  }

  private updateZone(dt: number) {
    if (this.zone.phase >= ZONE_PHASES.length && !this.zone.shrinking) {
      this.zone.dmg = ZONE_PHASES[ZONE_PHASES.length - 1]?.dmg ?? 22;
    } else if (this.zone.shrinking) {
      const ph = ZONE_PHASES[this.zone.phase] ?? ZONE_PHASES[ZONE_PHASES.length - 1];
      this.zone.t -= dt;
      const dur = ph.shrink;
      const k = 1 - clamp(this.zone.t / dur, 0, 1);
      this.zone.r = this.lerp(this.zone.r, this.zone.tr, 1 - Math.exp(-dt * 1.8));
      this.zone.x = this.lerp(this.zone.x, this.zone.tx, 1 - Math.exp(-dt * 1.6));
      this.zone.z = this.lerp(this.zone.z, this.zone.tz, 1 - Math.exp(-dt * 1.6));
      this.zone.dmg = ph.dmg;
      if (k >= 1 || this.zone.t <= 0) {
        this.zone.r = this.zone.tr;
        this.zone.x = this.zone.tx;
        this.zone.z = this.zone.tz;
        this.zone.shrinking = false;
        this.zone.phase += 1;
        const next = ZONE_PHASES[this.zone.phase];
        this.zone.t = next ? next.wait : 999;
      }
    } else {
      this.zone.t -= dt;
      const ph = ZONE_PHASES[this.zone.phase];
      this.zone.dmg = ph ? ph.dmg : 22;
      if (this.zone.t <= 0 && ph) {
        this.zone.shrinking = true;
        this.zone.tr = ph.radius;
        this.zone.t = ph.shrink;
        const maxShift = Math.max(0, this.zone.r - this.zone.tr);
        const ang = this.rng() * Math.PI * 2;
        const dist = this.rng() * maxShift * 0.65;
        this.zone.tx = this.zone.x + Math.cos(ang) * dist;
        this.zone.tz = this.zone.z + Math.sin(ang) * dist;
        this.audio.zone();
      }
    }
    for (const a of this.actors) {
      if (!a.alive || !a.grounded) continue;
      const d = Math.hypot(a.x - this.zone.x, a.z - this.zone.z);
      if (d > this.zone.r - 0.4) {
        this.hurt(a, this.zone.dmg * dt, -1, false);
      }
    }
  }

  private lerp(a: number, b: number, t: number) {
    return a + (b - a) * t;
  }

  private stepPlayer(dt: number) {
    const p = this.actors[0];
    if (!p?.alive) return;
    const look = this.input.consumeLook();
    if (this.input.mouseLooking > 0 || this.input.pointerLocked) {
      this.camYaw -= look.dx * 0.0024;
      this.camPitch = clamp(this.camPitch - look.dy * 0.002, -1.15, 0.35);
    }
    const move = this.input.sampleMove();
    if (this.injectedSteer != null) {
      this.camYaw += this.injectedSteer * 2.6 * dt;
    }
    const cf = this.camYaw;
    const fx = -Math.sin(cf);
    const fz = -Math.cos(cf);
    const rx = Math.cos(cf);
    const rz = -Math.sin(cf);
    let wx = rx * move.x + fx * move.y;
    let wz = rz * move.x + fz * move.y;
    const wlen = Math.hypot(wx, wz);
    if (wlen > 1e-4) {
      wx /= wlen;
      wz /= wlen;
      p.yaw = Math.atan2(-wx, -wz);
    }
    if (!p.grounded) {
      p.y -= PARA_FALL * dt;
      const sp = PARA_STEER;
      p.vx = wx * sp;
      p.vz = wz * sp;
      p.x += p.vx * dt;
      p.z += p.vz * dt;
      if (p.y <= 0) {
        p.y = 0;
        p.grounded = true;
        this.burst(p.x, 0.4, p.z, 8, 0xc9b07a);
      }
    } else {
      const sp = PLAYER_SPEED * (move.sprint ? SPRINT_MUL : 1);
      p.vx = wx * sp;
      p.vz = wz * sp;
      p.x += p.vx * dt;
      p.z += p.vz * dt;
      this.resolve(p);
    }
    p.aimX = fx;
    p.aimZ = fz;
    if (this.input.slotQueued != null) {
      if (this.input.slotQueued === -1) p.slot = (p.slot + 1) % 2;
      else if (this.input.slotQueued < 2) p.slot = this.input.slotQueued;
      this.input.slotQueued = null;
    }
    if (this.input.reloadQueued) {
      this.startReload(p);
      this.input.reloadQueued = false;
    }
    if (this.input.interactQueued) {
      this.tryLoot(p, true);
      this.input.interactQueued = false;
    } else {
      this.tryLoot(p, true);
    }
    const we = WEAPONS[this.weaponOf(p)];
    const wantFire = this.input.fireHeld || this.input.fireQueued;
    if (wantFire) this.tryFire(p, we.auto);
    this.input.fireQueued = false;
    if (p.reload > 0) {
      p.reload -= dt;
      if (p.reload <= 0) this.finishReload(p);
    }
    if (this.input.mouseLooking <= 0 && !this.input.pointerLocked && wlen > 0.15) {
      this.camYaw = angLerp(this.camYaw, p.yaw, 1 - Math.exp(-5.5 * dt));
    }
  }

  private stepBots(dt: number, freezeCombat: boolean) {
    const player = this.actors[0];
    for (const a of this.actors) {
      if (a.player || !a.alive) continue;
      a.aiT -= dt;
      if (!a.grounded) {
        a.y -= PARA_FALL * 0.92 * dt;
        const jx = Math.sin(a.id * 1.7 + this.clock) * 0.4;
        const jz = Math.cos(a.id * 1.3 + this.clock) * 0.4;
        a.x += jx * PARA_STEER * 0.4 * dt;
        a.z += jz * PARA_STEER * 0.4 * dt;
        if (a.y <= 0) {
          a.y = 0;
          a.grounded = true;
        }
        a.mesh.position.set(a.x, a.y, a.z);
        a.mesh.rotation.y = a.yaw;
        continue;
      }
      if (a.reload > 0) {
        a.reload -= dt;
        if (a.reload <= 0) this.finishReload(a);
      }
      const inZone = Math.hypot(a.x - this.zone.x, a.z - this.zone.z) < this.zone.r - 2.5;
      if (a.aiT <= 0) {
        a.aiT = 0.18 + Math.random() * 0.12;
        const we = this.weaponOf(a);
        const armed = we !== "melee";
        let tx = a.aimX;
        let tz = a.aimZ;
        let mode: "loot" | "fight" | "zone" | "roam" = "roam";
        if (!inZone) mode = "zone";
        else if (!armed) mode = "loot";
        else {
          let best: Actor | null = null;
          let bestD = 42;
          for (const o of this.actors) {
            if (o === a || !o.alive || !o.grounded) continue;
            const d = Math.hypot(o.x - a.x, o.z - a.z);
            if (d < bestD) {
              bestD = d;
              best = o;
            }
          }
          if (best && bestD < (we === "sniper" ? 70 : 38)) {
            mode = "fight";
            tx = best.x;
            tz = best.z;
          } else mode = "loot";
        }
        if (mode === "zone") {
          tx = this.zone.x;
          tz = this.zone.z;
        } else if (mode === "loot") {
          let ld = 1e9;
          let lx = this.zone.x,
            lz = this.zone.z;
          for (const l of this.loot) {
            if (!l.live) continue;
            const d = Math.hypot(l.x - a.x, l.z - a.z);
            if (d < ld) {
              ld = d;
              lx = l.x;
              lz = l.z;
            }
          }
          tx = lx;
          tz = lz;
        }
        a.aimX = tx;
        a.aimZ = tz;
        a.ai = mode === "fight" ? 2 : mode === "zone" ? 1 : 0;
      }
      const dx = a.aimX - a.x;
      const dz = a.aimZ - a.z;
      const dist = Math.hypot(dx, dz) || 1;
      let mx = dx / dist;
      let mz = dz / dist;
      for (const o of this.actors) {
        if (o === a || !o.alive) continue;
        const sx = a.x - o.x;
        const sz = a.z - o.z;
        const sd = Math.hypot(sx, sz);
        if (sd > 0.01 && sd < 2.2) {
          mx += (sx / sd) * 0.55;
          mz += (sz / sd) * 0.55;
        }
      }
      const ml = Math.hypot(mx, mz) || 1;
      mx /= ml;
      mz /= ml;
      const fight = a.ai === 2;
      const sp = PLAYER_SPEED * (fight ? 0.78 : 0.92);
      if (!fight || dist > 11) {
        a.vx = mx * sp;
        a.vz = mz * sp;
      } else {
        a.vx = -mz * sp * 0.7;
        a.vz = mx * sp * 0.7;
      }
      a.x += a.vx * dt;
      a.z += a.vz * dt;
      a.yaw = Math.atan2(-mx, -mz);
      this.resolve(a);
      this.tryLoot(a, true);
      if (!freezeCombat && fight && player.alive) {
        const we = WEAPONS[this.weaponOf(a)];
        const aimDx = player.x - a.x;
        const aimDz = player.z - a.z;
        const ad = Math.hypot(aimDx, aimDz);
        if (ad < we.range * 0.95 && ad > 1.4 && Math.random() > 0.25) {
          a.yaw = Math.atan2(-aimDx, -aimDz);
          a.aimX = player.x;
          a.aimZ = player.z;
          this.tryFire(a, true);
        }
      }
    }
  }

  private tryFire(a: Actor, auto: boolean) {
    const id = this.weaponOf(a);
    const we = WEAPONS[id];
    const interval = 60 / we.rpm;
    if (this.clock - a.lastShot < interval) return;
    if (a.reload > 0) return;
    if (id !== "melee" && a.mag <= 0) {
      this.startReload(a);
      return;
    }
    if (!auto && !a.player && Math.random() > 0.35) return;
    a.lastShot = this.clock;
    if (id !== "melee") a.mag -= 1;
    const originY = a.grounded ? 1.2 : a.y + 1.1;
    let fx: number, fz: number;
    if (a.player) {
      fx = -Math.sin(this.camYaw);
      fz = -Math.cos(this.camYaw);
    } else {
      fx = -Math.sin(a.yaw);
      fz = -Math.cos(a.yaw);
    }
    if (id === "melee") {
      this.meleeStrike(a, fx, fz, we.dmg);
      return;
    }
    if (a.player) this.audio.shoot(id === "shotgun" || id === "sniper");
    this.trauma = Math.min(1, this.trauma + (a.player ? 0.22 : 0.05));
    for (let i = 0; i < we.pellets; i++) {
      const spr = we.spread * (0.4 + Math.random());
      const ang = Math.random() * Math.PI * 2;
      const sx = fx + Math.cos(ang) * spr;
      const sz = fz + Math.sin(ang) * spr;
      const sl = Math.hypot(sx, sz) || 1;
      this.spawnBullet(a, a.x + (sx / sl) * 0.8, originY, a.z + (sz / sl) * 0.8, (sx / sl) * we.speed, 0, (sz / sl) * we.speed, we.dmg, we.range / we.speed);
    }
  }

  private meleeStrike(a: Actor, fx: number, fz: number, dmg: number) {
    for (const o of this.actors) {
      if (o === a || !o.alive) continue;
      const dx = o.x - a.x;
      const dz = o.z - a.z;
      const d = Math.hypot(dx, dz);
      if (d < 2.3 && dx * fx + dz * fz > 0) {
        this.hurt(o, dmg, a.id, true);
      }
    }
  }

  private spawnBullet(owner: Actor, x: number, y: number, z: number, vx: number, vy: number, vz: number, dmg: number, ttl: number) {
    const b = this.bullets.find((q) => !q.live);
    if (!b) return;
    b.live = true;
    b.x = x;
    b.y = y;
    b.z = z;
    b.vx = vx;
    b.vy = vy;
    b.vz = vz;
    b.ttl = ttl;
    b.dmg = dmg;
    b.owner = owner.id;
    b.mesh.visible = true;
    b.mesh.material = owner.player ? this.mats.bullet : this.mats.ebullet;
  }

  private stepBullets(dt: number) {
    for (const b of this.bullets) {
      if (!b.live) continue;
      const nx = b.x + b.vx * dt;
      const ny = b.y + b.vy * dt;
      const nz = b.z + b.vz * dt;
      if (this.hitBuild((b.x + nx) / 2, (b.z + nz) / 2, 0.1) || ny < 0.1) {
        b.live = false;
        b.mesh.visible = false;
        this.burst(nx, ny, nz, 4, 0xffe08a);
        continue;
      }
      let hit = false;
      for (const a of this.actors) {
        if (!a.alive || a.id === b.owner) continue;
        const dy = ny - (a.y + 1.0);
        if (Math.hypot(nx - a.x, nz - a.z) < 0.62 && Math.abs(dy) < 1.15) {
          this.hurt(a, b.dmg, b.owner, true);
          hit = true;
          break;
        }
      }
      b.ttl -= dt;
      if (hit || b.ttl <= 0) {
        b.live = false;
        b.mesh.visible = false;
        if (hit) this.burst(nx, ny, nz, 6, 0xff8866);
        continue;
      }
      b.x = nx;
      b.y = ny;
      b.z = nz;
      b.mesh.position.set(nx, ny, nz);
    }
  }

  private hurt(a: Actor, dmg: number, src: number, juice: boolean) {
    if (!a.alive || dmg <= 0) return;
    let left = dmg;
    if (a.armor > 0) {
      const use = Math.min(a.armor, left * 0.65);
      a.armor -= use;
      left -= use;
    }
    a.hp -= left;
    a.flash = 0.12;
    if (juice && a.player) {
      this.audio.hurt();
      this.trauma = Math.min(1, this.trauma + 0.4);
    }
    if (juice && src === 0) this.audio.hit();
    if (a.hp <= 0) {
      a.hp = 0;
      a.alive = false;
      a.mesh.visible = false;
      this.burst(a.x, 1, a.z, 16, a.color);
      const killer = this.actors[src];
      if (killer) killer.kills += 1;
      if (src === 0) {
        this.kills += 1;
        this.hitstop = 0.05;
        this.trauma = 0.7;
      }
      const kn = killer?.name ?? "ZONE";
      this.feed.unshift({ id: ++this.feedId, text: `${kn}  ·  ${a.name}`, t: this.clock });
      this.feed = this.feed.slice(0, 5);
      if (a.player) {
        this.placement = this.actors.filter((x) => x.alive).length + 1;
        this.finish(false);
      }
    }
  }

  private startReload(a: Actor) {
    const id = this.weaponOf(a);
    if (id === "melee") return;
    const we = WEAPONS[id];
    if (a.mag >= we.mag || a.reserve <= 0 || a.reload > 0) return;
    a.reload = 1.55;
  }

  private finishReload(a: Actor) {
    const id = this.weaponOf(a);
    if (id === "melee") return;
    const we = WEAPONS[id];
    const need = we.mag - a.mag;
    const take = Math.min(need, a.reserve);
    a.mag += take;
    a.reserve -= take;
    a.reload = 0;
  }

  private tryLoot(a: Actor, pickup: boolean) {
    this.prompt = null;
    let near: Loot | null = null;
    let nd = 1.7;
    for (const l of this.loot) {
      if (!l.live) continue;
      const d = Math.hypot(l.x - a.x, l.z - a.z);
      if (d < nd) {
        nd = d;
        near = l;
      }
    }
    if (!near || !a.grounded) return;
    if (a.player) this.prompt = near.kind;
    if (!pickup && a.player) return;
    const kind = near.kind;
    if (kind === "med") {
      if (a.hp >= 200) return;
      a.hp = Math.min(200, a.hp + 55);
    } else if (kind === "armor") {
      if (a.armor >= 100) return;
      a.armor = Math.min(100, a.armor + 50);
    } else if (kind === "ammo") {
      const id = this.weaponOf(a);
      if (id === "melee") return;
      a.reserve += WEAPONS[id].mag * 2;
    } else {
      const empty = a.slots.findIndex((s) => s == null);
      if (empty >= 0) {
        a.slots[empty] = kind;
        a.slot = empty;
      } else {
        a.slots[a.slot] = kind;
      }
      const we = WEAPONS[kind];
      a.mag = we.mag;
      a.reserve = we.reserve;
    }
    near.live = false;
    near.mesh.visible = false;
    if (a.player) this.audio.pickup();
  }

  private checkEnd() {
    const living = this.actors.filter((a) => a.alive);
    if (living.length <= 1 && this.mode === "playing") {
      const p = this.actors[0];
      if (p.alive) {
        this.placement = 1;
        this.finish(true);
      }
    }
  }

  private finish(won: boolean) {
    if (this.mode !== "playing") return;
    this.mode = "over";
    this.won = won;
    this.overT = 0;
    if (won) this.audio.win();
    else this.audio.lose();
    this.onOver(won, this.placement, this.kills);
    this.pushHud(true);
  }

  private burst(x: number, y: number, z: number, n: number, _color: number) {
    let c = 0;
    for (const p of this.particles) {
      if (p.t > 0) continue;
      p.t = 0.35 + Math.random() * 0.2;
      p.m.visible = true;
      p.m.position.set(x, y, z);
      p.vx = (Math.random() - 0.5) * 6;
      p.vy = 2 + Math.random() * 5;
      p.vz = (Math.random() - 0.5) * 6;
      c++;
      if (c >= n) break;
    }
  }

  private stepParticles(dt: number) {
    for (const p of this.particles) {
      if (p.t <= 0) continue;
      p.t -= dt;
      p.vy -= 12 * dt;
      p.m.position.x += p.vx * dt;
      p.m.position.y += p.vy * dt;
      p.m.position.z += p.vz * dt;
      if (p.t <= 0 || p.m.position.y < 0) {
        p.t = 0;
        p.m.visible = false;
      }
    }
  }

  private stepLoot() {
    const t = this.clock;
    for (const l of this.loot) {
      if (!l.live) continue;
      l.mesh.position.y = 0.32 + Math.sin(t * 2.5 + l.x) * 0.08;
      l.mesh.rotation.y += 0.01;
    }
  }

  private orbitMenu(dt: number) {
    this.camYaw += dt * 0.12;
    const r = 48;
    this.camera.position.set(Math.sin(this.camYaw) * r, 22, Math.cos(this.camYaw) * r);
    this.camera.lookAt(0, 1, 0);
  }

  private draw(dt: number) {
    this.trauma = Math.max(0, this.trauma - dt * 1.6);
    const shake = this.trauma * this.trauma;
    if (this.mode === "menu") {
      this.orbitMenu(dt);
    } else {
      const p = this.actors[0];
      const dist = p.grounded ? 6.8 : 11;
      const height = p.grounded ? 3.1 : 5.5;
      const fx = -Math.sin(this.camYaw);
      const fz = -Math.cos(this.camYaw);
      const rx = Math.cos(this.camYaw);
      const rz = -Math.sin(this.camYaw);
      const tx = p.x + rx * 0.55;
      const tz = p.z + rz * 0.55;
      const desired = this.tmp.set(tx - fx * dist, p.y + height - this.camPitch * 2.4, tz - fz * dist);
      this.camera.position.lerp(desired, 1 - Math.exp(-8 * dt));
      this.tmp2.set(p.x, p.y + 1.25, p.z);
      this.camera.lookAt(this.tmp2);
      if (shake > 0.002) {
        this.camera.position.x += (Math.random() - 0.5) * shake * 0.45;
        this.camera.position.y += (Math.random() - 0.5) * shake * 0.3;
      }
    }
    for (const a of this.actors) {
      if (!a.alive) continue;
      a.mesh.position.set(a.x, a.y, a.z);
      a.mesh.rotation.y = a.yaw;
      if (a.flash > 0) {
        a.flash -= dt;
        a.bodyMat.emissive.setHex(a.flash > 0 ? 0x442200 : 0x000000);
      }
    }
    this.zoneRing.position.set(this.zone.x, 0.08, this.zone.z);
    const zs = Math.max(0.05, this.zone.r / MAP_R);
    this.zoneRing.scale.set(zs, 1, zs);
    this.zoneWall.position.set(this.zone.x, 9, this.zone.z);
    this.zoneWall.scale.set(zs, 1, zs);
    if (this.mode === "playing") {
      this.planeMesh.position.x += 28 * dt;
      this.planeMesh.visible = this.planeMesh.position.x < 100;
    }
    this.renderer.render(this.scene, this.camera);
  }

  private wireProbe() {
    window.__controlsTest = {
      getYaw: () => this.actors[0]?.yaw ?? 0,
      getSpeed: () => {
        const p = this.actors[0];
        if (!p) return 0;
        return Math.hypot(p.vx, p.vz);
      },
      setKeys: (codes: string[]) => this.input.setKeys(codes),
      setSteer: (v: number) => {
        this.injectedSteer = v === 0 ? null : v;
      },
    };
  }

  private pushHud(force: boolean) {
    const p = this.actors[0];
    if (!p && !force) return;
    const weId = p ? this.weaponOf(p) : "melee";
    const we = WEAPONS[weId];
    const alive = this.actors.filter((a) => a.alive).length;
    const snap: HudSnapshot = {
      hp: p?.hp ?? 0,
      maxHp: 200,
      armor: p?.armor ?? 0,
      mag: p?.mag ?? 0,
      magSize: we.mag,
      reserve: p?.reserve ?? 0,
      weapon: weId,
      weaponName: we.name,
      weaponNameAr: we.nameAr,
      alive,
      kills: this.kills,
      zoneIn: p ? Math.hypot(p.x - this.zone.x, p.z - this.zone.z) < this.zone.r - 0.5 : true,
      zoneDmg: this.zone.dmg,
      zoneEta: this.zone.t,
      shrinking: this.zone.shrinking,
      prompt: this.prompt,
      grounded: p?.grounded ?? true,
      reloading: (p?.reload ?? 0) > 0,
      feed: this.feed,
      posX: p?.x ?? 0,
      posZ: p?.z ?? 0,
      yaw: p?.yaw ?? 0,
      others: this.actors.filter((a) => a.alive).map((a) => ({ x: a.x, z: a.z, self: a.player })),
      zoneX: this.zone.x,
      zoneZ: this.zone.z,
      zoneR: this.zone.r,
      nextR: this.zone.tr,
      mapR: MAP_R,
      placement: this.placement,
      won: this.won,
      slots: [0, 1].map((i) => {
        const id = p?.slots[i] ?? null;
        return { id, name: id ? WEAPONS[id].name : "—" };
      }),
      slot: p?.slot ?? 0,
      matchTime: this.matchTime,
    };
    this.onHud(snap);
  }
}
