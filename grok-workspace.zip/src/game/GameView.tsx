import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { GameOverlay } from "@/components/game-overlay";
import { LANG_KEY, NAME_KEY, STATS_KEY } from "./config";
import { BlazeGame } from "./engine";
import type { HudSnapshot, Stats } from "./types";

function loadStats(): Stats {
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (raw) return JSON.parse(raw) as Stats;
  } catch {
    /* ignore */
  }
  return { name: "RANGER", matches: 0, wins: 0, kills: 0, best: 16 };
}

function saveStats(s: Stats) {
  localStorage.setItem(STATS_KEY, JSON.stringify(s));
}

export function GameView() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<BlazeGame | null>(null);
  const pendingStart = useRef<string | null>(null);
  const [hud, setHud] = useState<HudSnapshot | null>(null);
  const [screen, setScreen] = useState<"menu" | "playing" | "over">("menu");
  const [stats, setStats] = useState<Stats>({ name: "RANGER", matches: 0, wins: 0, kills: 0, best: 16 });
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const [muted, setMuted] = useState(false);
  const [name, setName] = useState("RANGER");
  const [how, setHow] = useState(false);

  useEffect(() => {
    try {
      const n = localStorage.getItem(NAME_KEY);
      if (n) setName(n);
      const l = localStorage.getItem(LANG_KEY);
      if (l === "en" || l === "ar") setLang(l);
      setStats(loadStats());
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang === "ar" ? "ar" : "en";
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);

  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const inst = new BlazeGame(canvas, {
      onHud: (h) => setHud(h),
      onOver: (won, place, kills) => {
        setScreen("over");
        setStats((prev) => {
          const next: Stats = {
            ...prev,
            matches: prev.matches + 1,
            wins: prev.wins + (won ? 1 : 0),
            kills: prev.kills + kills,
            best: Math.min(prev.best || 16, place),
            name: prev.name,
          };
          saveStats(next);
          return next;
        });
      },
    });
    gameRef.current = inst;
    const queued = pendingStart.current;
    if (queued) {
      pendingStart.current = null;
      inst.audio.unlock();
      inst.setName(queued);
      inst.startMatch(queued);
      setScreen("playing");
    }
    const onVis = () => {
      if (!document.hidden) inst.audio.unlock();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      inst.destroy();
      gameRef.current = null;
    };
  }, []);

  const start = useCallback(() => {
    const g = gameRef.current;
    const trimmed = name.trim().slice(0, 14) || "RANGER";
    setName(trimmed);
    try {
      localStorage.setItem(NAME_KEY, trimmed);
    } catch {
      /* ignore */
    }
    if (!g) {
      pendingStart.current = trimmed;
      return;
    }
    g.audio.unlock();
    g.setName(trimmed);
    g.startMatch(trimmed);
    setScreen("playing");
    setStats((s) => ({ ...s, name: trimmed }));
  }, [name]);

  const backToMenu = useCallback(() => {
    setScreen("menu");
  }, []);

  const toggleLang = useCallback(() => {
    setLang((l) => {
      const n = l === "ar" ? "en" : "ar";
      try {
        localStorage.setItem(LANG_KEY, n);
      } catch {
        /* ignore */
      }
      return n;
    });
  }, []);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      gameRef.current?.audio.setMuted(next);
      return next;
    });
  }, []);

  const onJoy = useCallback((x: number, y: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.input.joyX = x;
    g.input.joyY = y;
  }, []);

  const onFire = useCallback((down: boolean) => {
    const g = gameRef.current;
    if (!g) return;
    g.input.fireHeld = down;
    if (down) g.input.fireQueued = true;
  }, []);

  const onReload = useCallback(() => {
    const g = gameRef.current;
    if (g) g.input.reloadQueued = true;
  }, []);

  const onLook = useCallback((dx: number, dy: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.input.lookDx += dx;
    g.input.lookDy += dy;
    g.input.mouseLooking = 0.5;
  }, []);

  const requestLock = useCallback(() => {
    if (screen !== "playing") return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    gameRef.current?.audio.unlock();
    const req = canvas.requestPointerLock as (opts?: { unadjustedMovement?: boolean }) => Promise<void> | void;
    try {
      const p = req.call(canvas, { unadjustedMovement: true });
      if (p && typeof (p as Promise<void>).catch === "function") {
        void (p as Promise<void>).catch(() => {
          canvas.requestPointerLock();
        });
      }
    } catch {
      try {
        canvas.requestPointerLock();
      } catch {
        /* iframe may block pointer lock */
      }
    }
  }, [screen]);

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-bg text-fg" style={{ touchAction: "none" }}>
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full"
        onClick={requestLock}
        onContextMenu={(e) => e.preventDefault()}
      />
      <GameOverlay
        screen={screen}
        hud={hud}
        stats={stats}
        lang={lang}
        muted={muted}
        name={name}
        how={how}
        onName={setName}
        onStart={start}
        onMenu={backToMenu}
        onLang={toggleLang}
        onMute={toggleMute}
        onHow={() => setHow((v) => !v)}
        onJoy={onJoy}
        onFire={onFire}
        onReload={onReload}
        onLook={onLook}
      />
    </div>
  );
}
