import { Crosshair, Volume2, VolumeX, Globe, RotateCcw } from "lucide-react";
import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import type { HudSnapshot, Stats } from "@/game/types";

function VirtualStick({
  onChange,
  onLook,
  look,
}: {
  onChange?: (x: number, y: number) => void;
  onLook?: (dx: number, dy: number) => void;
  look?: boolean;
}) {
  const pid = useRef<number | null>(null);
  const origin = useRef({ x: 0, y: 0 });
  const last = useRef({ x: 0, y: 0 });
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  const end = (e: ReactPointerEvent) => {
    if (pid.current !== e.pointerId) return;
    pid.current = null;
    setKnob({ x: 0, y: 0 });
    onChange?.(0, 0);
  };

  return (
    <div
      className="relative size-28 rounded-full border border-border bg-surface/55"
      onPointerDown={(e) => {
        pid.current = e.pointerId;
        (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
        origin.current = { x: e.clientX, y: e.clientY };
        last.current = { x: e.clientX, y: e.clientY };
      }}
      onPointerMove={(e) => {
        if (pid.current !== e.pointerId) return;
        if (look) {
          onLook?.(e.clientX - last.current.x, e.clientY - last.current.y);
          last.current = { x: e.clientX, y: e.clientY };
          const dx = e.clientX - origin.current.x;
          const dy = e.clientY - origin.current.y;
          const m = Math.min(40, Math.hypot(dx, dy));
          const a = Math.atan2(dy, dx);
          setKnob({ x: Math.cos(a) * m, y: Math.sin(a) * m });
          return;
        }
        const dx = e.clientX - origin.current.x;
        const dy = e.clientY - origin.current.y;
        const m = Math.hypot(dx, dy);
        const r = 42;
        const k = m > r ? r / m : 1;
        const x = (dx * k) / r;
        const y = (-dy * k) / r;
        setKnob({ x: dx * k, y: dy * k });
        onChange?.(x, y);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div
        className="absolute left-1/2 top-1/2 size-11 rounded-full bg-fg/80"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}

const copy = {
  ar: {
    kicker: "باتل رويال",
    tag: "١٦ مقاتل · جزيرة الجمر · آخر واقف",
    start: "Start",
    startSub: "ابدأ المعركة",
    name: "الاسم",
    how: "كيف تلعب",
    hide: "إخفاء",
    howBody: [
      "الهبوط بالمظلة ثم اجمع سلاحاً ودروعاً.",
      "WASD أو العصا اليسرى للحركة. الماوس أو العصا اليمنى للنظر.",
      "اضغط للإطلاق · R لإعادة التعبئة · F للالتقاط.",
      "ابق داخل المنطقة الآمنة. الدائرة تضيق.",
      "آخر مقاتل يقف يفوز بالتاج.",
    ],
    matches: "مباريات",
    wins: "انتصارات",
    kills: "قتل",
    best: "أفضل مركز",
    alive: "على قيد الحياة",
    drop: "اهبط",
    outside: "خارج المنطقة",
    reload: "تعبئة",
    fire: "إطلاق",
    crowned: "التاج",
    fallen: "سقطت",
    place: "المركز",
    again: "Start",
    menu: "القائمة",
    pickup: "التقط",
  },
  en: {
    kicker: "Battle Royale",
    tag: "16 fighters · Cinder Atoll · last standing",
    start: "Start",
    startSub: "Drop into the blaze",
    name: "Callsign",
    how: "How to play",
    hide: "Hide",
    howBody: [
      "Parachute in, then loot a weapon and armor.",
      "WASD or left stick to move. Mouse or right stick to look.",
      "Click to fire · R to reload · F to pick up.",
      "Stay inside the safe zone. The ring closes.",
      "Last fighter standing takes the crown.",
    ],
    matches: "Matches",
    wins: "Wins",
    kills: "Kills",
    best: "Best",
    alive: "Alive",
    drop: "Steer the drop",
    outside: "Outside the zone",
    reload: "Reload",
    fire: "Fire",
    crowned: "Crowned",
    fallen: "Eliminated",
    place: "Place",
    again: "Start",
    menu: "Menu",
    pickup: "Pick up",
  },
};

function fmtTime(t: number) {
  const s = Math.max(0, Math.ceil(t));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${r.toString().padStart(2, "0")}`;
}

function Minimap({ hud }: { hud: HudSnapshot }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const w = c.width;
    const h = c.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "rgba(20, 28, 24, 0.92)";
    ctx.fillRect(0, 0, w, h);
    const scale = (w * 0.42) / hud.mapR;
    const cx = w / 2;
    const cy = h / 2;
    const wx = (x: number, z: number) => [cx + x * scale, cy + z * scale] as const;
    ctx.strokeStyle = "rgba(94, 224, 192, 0.85)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(...wx(hud.zoneX, hud.zoneZ), hud.zoneR * scale, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = "rgba(232, 93, 4, 0.35)";
    ctx.beginPath();
    ctx.arc(cx, cy, hud.mapR * scale, 0, Math.PI * 2);
    ctx.stroke();
    for (const o of hud.others) {
      const [px, pz] = wx(o.x, o.z);
      ctx.fillStyle = o.self ? "#e85d04" : "#ece8e1";
      ctx.beginPath();
      ctx.arc(px, pz, o.self ? 3.2 : 1.6, 0, Math.PI * 2);
      ctx.fill();
    }
    const self = hud.others.find((o) => o.self);
    if (self) {
      const [px, pz] = wx(self.x, self.z);
      ctx.strokeStyle = "#ece8e1";
      ctx.beginPath();
      ctx.moveTo(px, pz);
      ctx.lineTo(px - Math.sin(hud.yaw) * 8, pz - Math.cos(hud.yaw) * 8);
      ctx.stroke();
    }
  }, [hud]);
  return <canvas ref={ref} width={148} height={148} className="size-[92px] rounded-md sm:size-[132px]" />;
}

export function GameOverlay({
  screen,
  hud,
  stats,
  lang,
  muted,
  name,
  how,
  onName,
  onStart,
  onMenu,
  onLang,
  onMute,
  onHow,
  onJoy,
  onFire,
  onReload,
  onLook,
}: {
  screen: "menu" | "playing" | "over";
  hud: HudSnapshot | null;
  stats: Stats;
  lang: "ar" | "en";
  muted: boolean;
  name: string;
  how: boolean;
  onName: (v: string) => void;
  onStart: () => void;
  onMenu: () => void;
  onLang: () => void;
  onMute: () => void;
  onHow: () => void;
  onJoy: (x: number, y: number) => void;
  onFire: (d: boolean) => void;
  onReload: () => void;
  onLook: (dx: number, dy: number) => void;
}) {
  const t = copy[lang];
  const rtl = lang === "ar";

  return (
    <div className="pointer-events-none absolute inset-0" dir={rtl ? "rtl" : "ltr"}>
      <div className="pointer-events-auto absolute inset-x-0 top-0 flex items-start justify-between p-3 pt-[max(0.75rem,env(safe-area-inset-top))] sm:p-5">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onLang}
            className="flex size-11 items-center justify-center rounded-md border border-border bg-surface/80 text-fg"
            aria-label="Language"
          >
            <Globe className="size-4" />
          </button>
          <button
            type="button"
            onClick={onMute}
            className="flex size-11 items-center justify-center rounded-md border border-border bg-surface/80 text-fg"
            aria-label="Mute"
          >
            {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </button>
        </div>
        {screen === "playing" && hud ? (
          <div className="flex flex-col items-end gap-2">
            <div className="rounded-md border border-border bg-surface/80 px-3 py-1.5 text-center">
              <div className="font-display text-lg font-semibold tabular-nums leading-none">{hud.alive}</div>
              <div className="text-[11px] text-muted">{t.alive}</div>
            </div>
            <Minimap hud={hud} />
          </div>
        ) : (
          <div />
        )}
      </div>

      {screen === "playing" && hud && (
        <>
          <div className="absolute left-1/2 top-[46%] -translate-x-1/2 -translate-y-1/2 text-fg/80">
            <Crosshair className="size-5" strokeWidth={1.75} />
          </div>
          <div className="absolute left-3 top-16 flex max-w-[48%] flex-col gap-1 sm:left-5 sm:top-20">
            {hud.feed.map((f) => (
              <div key={f.id} className="truncate rounded-sm bg-surface/70 px-2 py-1 text-xs text-fg">
                {f.text}
              </div>
            ))}
          </div>
          <div className="absolute left-1/2 top-3 w-[min(90%,20rem)] -translate-x-1/2 pt-[env(safe-area-inset-top)] text-center">
            <div className="font-display text-xs font-semibold uppercase tracking-[0.18em] text-muted">
              {hud.shrinking ? (rtl ? "الدائرة تضيق" : "Zone closing") : (rtl ? "المنطقة الآمنة" : "Safe zone")}
            </div>
            <div className={`font-display text-2xl font-semibold tabular-nums ${hud.zoneIn ? "text-fg" : "text-danger"}`}>
              {fmtTime(hud.zoneEta)}
            </div>
            {!hud.zoneIn && <div className="text-xs font-medium text-danger">{t.outside}</div>}
            {!hud.grounded && <div className="text-sm text-fg">{t.drop}</div>}
          </div>
          <div className="pointer-events-auto absolute inset-x-0 bottom-0 flex flex-col gap-2 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:p-5">
            <div className="mx-auto w-full max-w-md">
              {hud.prompt && (
                <div className="mb-2 text-center text-sm text-fg">
                  {t.pickup} · {hud.prompt}
                </div>
              )}
              <div className="mb-1 flex justify-between text-[11px] uppercase tracking-wider text-muted">
                <span>HP {Math.ceil(hud.hp)}</span>
                <span>
                  {hud.reloading ? t.reload : `${hud.weaponName}`}
                  {hud.magSize > 0 ? `  ${hud.mag}/${hud.reserve}` : ""}
                </span>
                <span>
                  {t.kills} {hud.kills}
                </span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-elevated">
                <div className="h-full bg-hp" style={{ width: `${(hud.hp / hud.maxHp) * 100}%` }} />
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-elevated">
                <div className="h-full bg-armor" style={{ width: `${hud.armor}%` }} />
              </div>
              <div className="mt-2 flex gap-2">
                {hud.slots.map((s, i) => (
                  <div
                    key={i}
                    className={`flex-1 rounded-md border px-2 py-1.5 text-center text-xs ${
                      hud.slot === i ? "border-accent bg-elevated text-fg" : "border-border bg-surface/70 text-muted"
                    }`}
                  >
                    {s.name}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex items-end justify-between md:hidden">
              <VirtualStick onChange={onJoy} />
              <div className="flex flex-col items-end gap-3">
                <VirtualStick look onLook={onLook} />
                <div className="flex items-end gap-3">
                  <button
                    type="button"
                    onPointerDown={onReload}
                    className="flex size-12 items-center justify-center rounded-full border border-border bg-surface/80"
                    aria-label={t.reload}
                  >
                    <RotateCcw className="size-4" />
                  </button>
                  <button
                    type="button"
                    onPointerDown={() => onFire(true)}
                    onPointerUp={() => onFire(false)}
                    onPointerCancel={() => onFire(false)}
                    className="flex size-[4.5rem] items-center justify-center rounded-full border border-accent bg-accent text-sm font-semibold text-accent-fg"
                  >
                    {t.fire}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {screen === "menu" && (
        <div className="pointer-events-auto absolute inset-0 flex items-end sm:items-center sm:justify-start">
          <div className="w-full max-w-lg bg-gradient-to-t from-bg via-bg/85 to-transparent p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:h-full sm:bg-gradient-to-r sm:from-bg sm:via-bg/80 sm:to-transparent sm:p-10 rtl:sm:bg-gradient-to-l">
            <p className="mb-2 font-display text-xs font-semibold uppercase tracking-[0.28em] text-accent">{t.kicker}</p>
            <h1 className="font-display text-5xl font-extrabold leading-none tracking-tight text-fg text-balance sm:text-7xl">
              BLAZE
              <br />
              DROP
            </h1>
            <p className="mt-3 max-w-sm text-pretty text-sm text-muted">{t.tag}</p>
            <label className="mt-6 block text-xs text-muted">
              {t.name}
              <input
                value={name}
                onChange={(e) => onName(e.target.value.toUpperCase())}
                maxLength={14}
                className="mt-1 block h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm tracking-wide text-fg outline-none focus:border-accent"
              />
            </label>
            <button
              type="button"
              onClick={onStart}
              className="mt-4 flex h-12 w-full items-center justify-center rounded-md bg-fg text-sm font-semibold text-bg transition-transform duration-150 ease-out hover:opacity-90 active:scale-[0.98]"
            >
              {t.start}
              <span className="mx-2 text-subtle">·</span>
              {t.startSub}
            </button>
            <button type="button" onClick={onHow} className="mt-2 h-11 w-full rounded-md border border-border text-sm text-muted">
              {how ? t.hide : t.how}
            </button>
            {how && (
              <ul className="mt-3 space-y-1.5 text-sm text-muted">
                {t.howBody.map((line) => (
                  <li key={line}>{line}</li>
                ))}
              </ul>
            )}
            <div className="mt-6 grid grid-cols-4 gap-2 border-t border-border pt-4">
              {[
                [t.matches, stats.matches],
                [t.wins, stats.wins],
                [t.kills, stats.kills],
                [t.best, stats.best === 16 && stats.matches === 0 ? "—" : `#${stats.best}`],
              ].map(([k, v]) => (
                <div key={String(k)}>
                  <div className="font-display text-lg font-semibold tabular-nums text-fg">{v}</div>
                  <div className="text-[11px] text-muted">{k}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {screen === "over" && hud && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-bg/70 p-5">
          <div className="w-full max-w-sm rounded-xl border border-border bg-surface p-6">
            <p className="font-display text-xs font-semibold uppercase tracking-[0.24em] text-accent">
              {hud.won ? t.crowned : t.fallen}
            </p>
            <h2 className="mt-2 font-display text-4xl font-extrabold tabular-nums">
              {t.place} #{hud.placement}
            </h2>
            <p className="mt-2 text-sm text-muted">
              {t.kills} {hud.kills}
            </p>
            <button
              type="button"
              onClick={onStart}
              className="mt-6 flex h-12 w-full items-center justify-center rounded-md bg-fg text-sm font-semibold text-bg"
            >
              {t.again}
            </button>
            <button
              type="button"
              onClick={onMenu}
              className="mt-2 h-11 w-full rounded-md border border-border text-sm text-muted"
            >
              {t.menu}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
